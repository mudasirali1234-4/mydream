// ============================================================================
// CineGenius — Core Domain Types
// Single source of truth for the timeline, AI pipeline, and rendering engine.
// ============================================================================

export type TrackType =
  | 'video'
  | 'audio'
  | 'bgm'
  | 'subtitle'
  | 'overlay3d'
  | 'map';

export interface BaseClip {
  id: string;
  trackId: string;
  /** Position on the timeline, in seconds */
  start: number;
  /** Duration on the timeline, in seconds */
  duration: number;
  /** In/out points relative to the source asset, in seconds */
  sourceIn: number;
  sourceOut: number;
  label: string;
  locked?: boolean;
  muted?: boolean;
}

export interface VideoClip extends BaseClip {
  type: 'video';
  assetId: string;
  thumbnailUrl?: string;
  transitionIn?: TransitionConfig;
  transitionOut?: TransitionConfig;
  speed: number; // 1 = normal, 0.5 = slow-mo, 2 = fast-forward
  filters?: VideoFilter[];
}

export interface AudioClip extends BaseClip {
  type: 'audio' | 'bgm';
  assetId: string;
  volume: number; // 0..1
  /** Ducking config applied when overlapping voice/dialogue tracks */
  ducking?: DuckingConfig;
  fadeInMs?: number;
  fadeOutMs?: number;
}

export interface SubtitleClip extends BaseClip {
  type: 'subtitle';
  text: string;
  /** Word-level timing for karaoke-style progressive highlighting */
  words?: WordTiming[];
  style: SubtitleStyle;
}

export interface Overlay3DClip extends BaseClip {
  type: 'overlay3d';
  modelUrl: string; // .glb/.gltf
  position: Vector3;
  rotation: Vector3;
  scale: Vector3;
  animationClip?: string;
  entrance?: 'fade' | 'pop' | 'slide' | 'none';
}

export interface MapClip extends BaseClip {
  type: 'map';
  route: GeoPoint[];
  style: 'satellite' | 'streets' | 'dark' | 'terrain';
  animateRoute: boolean;
  markers?: { point: GeoPoint; label: string }[];
}

export type Clip =
  | VideoClip
  | AudioClip
  | SubtitleClip
  | Overlay3DClip
  | MapClip;

export interface Track {
  id: string;
  type: TrackType;
  name: string;
  order: number;
  height: number;
  visible: boolean;
  locked: boolean;
  clipIds: string[];
}

export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface GeoPoint {
  lat: number;
  lng: number;
  timestamp?: number;
}

export interface WordTiming {
  word: string;
  start: number;
  end: number;
}

export interface SubtitleStyle {
  fontFamily: string;
  fontSize: number;
  color: string;
  highlightColor: string;
  position: 'top' | 'center' | 'bottom';
  bgOpacity: number;
}

export interface DuckingConfig {
  enabled: boolean;
  /** dB reduction applied to BGM while dialogue is present */
  reductionDb: number;
  attackMs: number;
  releaseMs: number;
}

export interface TransitionConfig {
  kind: 'cut' | 'crossfade' | 'whip-pan' | 'zoom' | 'glitch' | 'slide';
  durationMs: number;
}

export interface VideoFilter {
  kind: 'saturation' | 'contrast' | 'brightness' | 'lut' | 'blur' | 'vignette';
  value: number;
}

export interface MediaAsset {
  id: string;
  projectId: string;
  filename: string;
  kind: 'video' | 'audio' | 'image' | 'document';
  url: string;
  durationSec?: number;
  width?: number;
  height?: number;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  fps: number;
  width: number;
  height: number;
  durationSec: number;
  tracks: Track[];
  clips: Record<string, Clip>;
  assets: MediaAsset[];
  scriptAlignment?: ScriptAlignment;
}

// ---------------------------------------------------------------------------
// AI Document-to-Video engine
// ---------------------------------------------------------------------------

export interface ScriptMilestone {
  id: string;
  /** Character offset range in the source document */
  textRange: [number, number];
  excerpt: string;
  /** Narrative beat type — informs which automated editing action fires */
  beatType:
    | 'hook'
    | 'claim'
    | 'evidence'
    | 'emotional-peak'
    | 'call-to-action'
    | 'transition'
    | 'punchline';
  suggestedAction: EditingAction;
  /** Populated once aligned against the transcript */
  mappedTimestamp?: number;
  confidence: number; // 0..1
}

export interface EditingAction {
  kind:
    | 'smart-cut'
    | 'slow-motion'
    | 'text-highlight'
    | 'zoom-punch'
    | 'bgm-swell'
    | 'map-reveal'
    | 'overlay-3d';
  params: Record<string, unknown>;
}

export interface ScriptAlignment {
  documentId: string;
  milestones: ScriptMilestone[];
  transcript?: TranscriptResult;
  alignedAt: string;
}

export interface TranscriptResult {
  fullText: string;
  segments: TranscriptSegment[];
  language: string;
}

export interface TranscriptSegment {
  id: string;
  start: number;
  end: number;
  text: string;
  words: WordTiming[];
}

// ---------------------------------------------------------------------------
// Thumbnail generation
// ---------------------------------------------------------------------------

export interface ThumbnailCandidate {
  id: string;
  sourceTimestamp: number;
  frameUrl: string;
  /** Heuristic/AI-scored "click-through" impact score, 0..100 */
  impactScore: number;
  reasons: string[];
}

export interface ThumbnailComposition {
  id: string;
  candidateId: string;
  headline: string;
  subhead?: string;
  layout: 'left-text' | 'right-text' | 'bottom-banner' | 'burst';
  outputUrl?: string;
}

// ---------------------------------------------------------------------------
// Render / export pipeline
// ---------------------------------------------------------------------------

export interface RenderJob {
  id: string;
  projectId: string;
  status: 'queued' | 'processing' | 'complete' | 'failed';
  progress: number; // 0..100
  outputUrl?: string;
  error?: string;
  createdAt: string;
  target: RenderTarget;
}

export interface RenderTarget {
  resolution: '1080p' | '4K' | '9:16' | '1:1';
  format: 'mp4' | 'webm' | 'mov';
  quality: 'draft' | 'standard' | 'high';
}
