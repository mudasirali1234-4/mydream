import { nanoid } from 'nanoid';
import type { Project } from '@/lib/types';

export function createEmptyProject(id: string, name = 'Untitled Project'): Project {
  const now = new Date().toISOString();
  return {
    id,
    name,
    createdAt: now,
    updatedAt: now,
    fps: 30,
    width: 1920,
    height: 1080,
    durationSec: 120,
    tracks: [
      { id: nanoid(), type: 'video', name: 'Video', order: 0, height: 90, visible: true, locked: false, clipIds: [] },
      { id: nanoid(), type: 'subtitle', name: 'Subtitles', order: 1, height: 56, visible: true, locked: false, clipIds: [] },
      { id: nanoid(), type: 'bgm', name: 'Music', order: 2, height: 56, visible: true, locked: false, clipIds: [] },
    ],
    clips: {},
    assets: [],
  };
}
