// ============================================================================
// Client-Side Video Processing (ffmpeg.wasm)
// Handles frame extraction, scene-change detection, audio extraction, and
// proxy transcoding entirely in-browser so creators get instant feedback
// without round-tripping large source files to a server. Heavy final
// renders are still handed off to the server-side render pipeline
// (see app/api/render/route.ts) for speed and reliability.
// ============================================================================

import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

const CORE_VERSION = '0.12.6';
const CORE_BASE_URL = `https://unpkg.com/@ffmpeg/core@${CORE_VERSION}/dist/esm`;

async function getFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance) return ffmpegInstance;
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    const ffmpeg = new FFmpeg();
    await ffmpeg.load({
      coreURL: await toBlobURL(`${CORE_BASE_URL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${CORE_BASE_URL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  return loadPromise;
}

/** Extracts a single JPEG frame at the given timestamp, returns an object URL. */
export async function extractFrameAt(videoUrl: string, timestampSec: number): Promise<string> {
  const ffmpeg = await getFFmpeg();
  const inputName = 'input.mp4';
  const outputName = `frame_${Math.round(timestampSec * 1000)}.jpg`;

  await ffmpeg.writeFile(inputName, await fetchFile(videoUrl));
  await ffmpeg.exec([
    '-ss', timestampSec.toFixed(3),
    '-i', inputName,
    '-frames:v', '1',
    '-q:v', '3',
    outputName,
  ]);

  const data = await ffmpeg.readFile(outputName);
  const blob = new Blob([data], { type: 'image/jpeg' });
  return URL.createObjectURL(blob);
}

export interface SceneChangeOptions {
  /** ffmpeg scene detection sensitivity, 0..1. Lower = more scenes detected. */
  threshold?: number;
  /** Minimum gap between detected scene changes, to avoid clustering. */
  minGapSec?: number;
}

/**
 * Uses ffmpeg's `select='gt(scene,threshold)'` filter to detect hard cuts
 * and significant visual changes — the raw material for both automated
 * smart-cut suggestions and thumbnail candidate frames.
 */
export async function detectSceneChanges(
  videoUrl: string,
  opts: SceneChangeOptions = {}
): Promise<number[]> {
  const threshold = opts.threshold ?? 0.4;
  const minGap = opts.minGapSec ?? 1.5;
  const ffmpeg = await getFFmpeg();

  const inputName = 'scene_input.mp4';
  await ffmpeg.writeFile(inputName, await fetchFile(videoUrl));

  const timestamps: number[] = [];
  const logHandler = ({ message }: { message: string }) => {
    // ffmpeg showinfo emits lines like: "... pts_time:12.345 ..."
    const match = message.match(/pts_time:([\d.]+)/);
    if (match) timestamps.push(parseFloat(match[1]));
  };
  ffmpeg.on('log', logHandler);

  try {
    await ffmpeg.exec([
      '-i', inputName,
      '-vf', `select='gt(scene,${threshold})',showinfo`,
      '-f', 'null',
      '-',
    ]);
  } finally {
    // Must pass the SAME handler reference used in .on(), otherwise the
    // listener is never removed and leaks across every subsequent call
    // (ffmpeg is a module-level singleton — see getFFmpeg() above).
    ffmpeg.off('log', logHandler);
  }

  // De-duplicate/merge timestamps closer than minGap
  const sorted = [...new Set(timestamps)].sort((a, b) => a - b);
  const merged: number[] = [];
  for (const ts of sorted) {
    if (merged.length === 0 || ts - merged[merged.length - 1] >= minGap) {
      merged.push(ts);
    }
  }
  return merged;
}

/** Extracts the audio track as a WAV file, for transcription/waveform display. */
export async function extractAudioTrack(videoUrl: string): Promise<Blob> {
  const ffmpeg = await getFFmpeg();
  const inputName = 'audio_input.mp4';
  const outputName = 'audio_output.wav';

  await ffmpeg.writeFile(inputName, await fetchFile(videoUrl));
  await ffmpeg.exec([
    '-i', inputName,
    '-vn',
    '-acodec', 'pcm_s16le',
    '-ar', '16000',
    '-ac', '1',
    outputName,
  ]);

  const data = await ffmpeg.readFile(outputName);
  return new Blob([data], { type: 'audio/wav' });
}

/** Generates a lightweight, low-res proxy for smooth scrubbing on large source files. */
export async function generateProxy(videoUrl: string): Promise<Blob> {
  const ffmpeg = await getFFmpeg();
  const inputName = 'proxy_input.mp4';
  const outputName = 'proxy_output.mp4';

  await ffmpeg.writeFile(inputName, await fetchFile(videoUrl));
  await ffmpeg.exec([
    '-i', inputName,
    '-vf', 'scale=640:-2',
    '-c:v', 'libx264',
    '-preset', 'ultrafast',
    '-crf', '30',
    '-c:a', 'aac',
    '-b:a', '96k',
    outputName,
  ]);

  const data = await ffmpeg.readFile(outputName);
  return new Blob([data], { type: 'video/mp4' });
}

export function onProgress(cb: (ratio: number) => void): () => void {
  let unsub = () => {};
  getFFmpeg().then((ffmpeg) => {
    const handler = ({ progress }: { progress: number }) => cb(progress);
    ffmpeg.on('progress', handler);
    unsub = () => ffmpeg.off('progress', handler);
  });
  return () => unsub();
}
