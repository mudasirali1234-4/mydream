// ============================================================================
// Script & Document Parser
// Analyzes a raw script/document, extracts narrative milestones (hooks,
// claims, evidence, emotional peaks, CTAs, punchlines) and proposes
// automated editing actions for each. This module calls out to an LLM
// (Claude/GPT) for the semantic pass, with a deterministic rule-based
// fallback so the feature degrades gracefully without an API key.
// ============================================================================

import type { EditingAction, ScriptMilestone } from '@/lib/types';
import { nanoid } from 'nanoid';

export interface ParseScriptOptions {
  /** Raw text extracted from the uploaded document (.txt/.docx/.pdf) */
  text: string;
  /** Creator style preset informs which actions get suggested */
  style?: 'documentary' | 'high-retention' | 'vlog' | 'explainer';
  provider?: 'anthropic' | 'openai' | 'heuristic';
}

const SYSTEM_PROMPT = `You are a professional video editor's story analyst.
Given a raw script or narration document, break it into narrative
milestones a video editor would treat as distinct beats: hooks, claims,
supporting evidence, emotional peaks, transitions, punchlines, and calls
to action.

Return ONLY valid JSON — an array of objects shaped exactly like:
[
  {
    "excerpt": "<15-25 word verbatim excerpt from the source>",
    "textStart": <character offset int>,
    "textEnd": <character offset int>,
    "beatType": "hook" | "claim" | "evidence" | "emotional-peak" | "call-to-action" | "transition" | "punchline",
    "suggestedActionKind": "smart-cut" | "slow-motion" | "text-highlight" | "zoom-punch" | "bgm-swell" | "map-reveal" | "overlay-3d",
    "confidence": <float 0..1>
  }
]
No prose, no markdown fences — JSON only.`;

/**
 * Calls Claude (Anthropic) to semantically segment the script into
 * narrative milestones. Falls back to the heuristic parser on any error
 * so the editor never blocks on an AI outage.
 */
export async function parseScript(
  opts: ParseScriptOptions
): Promise<ScriptMilestone[]> {
  const provider = opts.provider ?? 'anthropic';

  if (provider === 'heuristic') {
    return heuristicParse(opts.text);
  }

  try {
    const raw = await callLLM(opts);
    return hydrateMilestones(raw, opts.text);
  } catch (err) {
    console.warn('[scriptParser] LLM parse failed, falling back to heuristic', err);
    return heuristicParse(opts.text);
  }
}

async function callLLM(opts: ParseScriptOptions): Promise<RawMilestone[]> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY not configured');

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4096,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `Style preset: ${opts.style ?? 'high-retention'}\n\nDOCUMENT:\n${opts.text}`,
        },
      ],
    }),
  });

  if (!res.ok) throw new Error(`LLM request failed: ${res.status}`);
  const data = await res.json();
  const textBlock = data.content?.find((c: any) => c.type === 'text');
  if (!textBlock?.text) throw new Error('Empty LLM response');

  const cleaned = textBlock.text.replace(/```json|```/g, '').trim();
  return JSON.parse(cleaned) as RawMilestone[];
}

interface RawMilestone {
  excerpt: string;
  textStart: number;
  textEnd: number;
  beatType: ScriptMilestone['beatType'];
  suggestedActionKind: EditingAction['kind'];
  confidence: number;
}

function hydrateMilestones(raw: RawMilestone[], sourceText: string): ScriptMilestone[] {
  return raw
    .filter((m) => m.excerpt && sourceText.includes(m.excerpt))
    .map((m) => ({
      id: nanoid(),
      textRange: [m.textStart, m.textEnd] as [number, number],
      excerpt: m.excerpt,
      beatType: m.beatType,
      confidence: clamp01(m.confidence),
      suggestedAction: buildAction(m.suggestedActionKind, m.beatType),
    }));
}

function buildAction(
  kind: EditingAction['kind'],
  beat: ScriptMilestone['beatType']
): EditingAction {
  switch (kind) {
    case 'slow-motion':
      return { kind, params: { speed: 0.5, rampMs: 400 } };
    case 'text-highlight':
      return { kind, params: { style: beat === 'punchline' ? 'bold-pop' : 'underline' } };
    case 'zoom-punch':
      return { kind, params: { scale: 1.15, durationMs: 250 } };
    case 'bgm-swell':
      return { kind, params: { gainDb: 4, durationMs: 1500 } };
    case 'map-reveal':
      return { kind, params: { animateRoute: true } };
    case 'overlay-3d':
      return { kind, params: { entrance: 'pop' } };
    case 'smart-cut':
    default:
      return { kind: 'smart-cut', params: { transition: 'whip-pan', durationMs: 180 } };
  }
}

function clamp01(n: number): number {
  return Math.min(1, Math.max(0, Number.isFinite(n) ? n : 0.5));
}

// ---------------------------------------------------------------------------
// Deterministic fallback — used when no LLM key is present, or as a
// safety net. Splits on sentence boundaries and applies lightweight
// heuristics (question marks -> hook, numbers/"studies show" -> evidence,
// exclamation/short punchy sentences -> punchline, etc.)
// ---------------------------------------------------------------------------

function heuristicParse(text: string): ScriptMilestone[] {
  const sentences = splitSentences(text);
  const milestones: ScriptMilestone[] = [];
  let cursor = 0;

  sentences.forEach((sentence, idx) => {
    const start = text.indexOf(sentence, cursor);
    const end = start + sentence.length;
    cursor = end;

    const beatType = classifySentence(sentence, idx, sentences.length);
    if (!beatType) return;

    const actionKind = defaultActionForBeat(beatType);
    milestones.push({
      id: nanoid(),
      textRange: [start, end],
      excerpt: sentence.trim(),
      beatType,
      confidence: 0.55,
      suggestedAction: buildAction(actionKind, beatType),
    });
  });

  return milestones;
}

function splitSentences(text: string): string[] {
  return text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function classifySentence(
  sentence: string,
  index: number,
  total: number
): ScriptMilestone['beatType'] | null {
  const lower = sentence.toLowerCase();

  if (index === 0) return 'hook';
  if (index === total - 1) return 'call-to-action';
  if (/\?$/.test(sentence)) return 'hook';
  if (/studies show|research|percent|%|data shows|according to/.test(lower))
    return 'evidence';
  if (/subscribe|follow|link in|comment below|let me know/.test(lower))
    return 'call-to-action';
  if (sentence.length < 40 && /!$/.test(sentence)) return 'punchline';
  if (/but here'?s the thing|however|meanwhile|turns out/.test(lower))
    return 'transition';
  if (/imagine|felt|heartbreaking|shocking|terrifying|incredible/.test(lower))
    return 'emotional-peak';

  return null;
}

function defaultActionForBeat(beat: ScriptMilestone['beatType']): EditingAction['kind'] {
  switch (beat) {
    case 'hook':
      return 'zoom-punch';
    case 'evidence':
      return 'text-highlight';
    case 'emotional-peak':
      return 'slow-motion';
    case 'punchline':
      return 'text-highlight';
    case 'transition':
      return 'smart-cut';
    case 'call-to-action':
      return 'bgm-swell';
    default:
      return 'smart-cut';
  }
}
