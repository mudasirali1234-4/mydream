// ============================================================================
// Script <-> Transcript Alignment
// Once we have (a) narrative milestones extracted from the uploaded
// document and (b) a word-level transcript of the actual footage audio,
// this module fuzzy-matches milestone excerpts against the transcript to
// derive a concrete video timestamp for each milestone. That timestamp is
// what drives automated cuts, highlights, and overlay triggers.
// ============================================================================

import type { ScriptMilestone, TranscriptResult, WordTiming } from '@/lib/types';

const WINDOW_PADDING_WORDS = 6;

export function alignMilestonesToTranscript(
  milestones: ScriptMilestone[],
  transcript: TranscriptResult
): ScriptMilestone[] {
  const allWords: WordTiming[] = transcript.segments.flatMap((s) => s.words);
  const normalizedWords = allWords.map((w) => normalize(w.word));

  return milestones.map((milestone) => {
    const targetTokens = normalize(milestone.excerpt).split(' ').filter(Boolean);
    if (targetTokens.length === 0) return milestone;

    const bestMatch = findBestWindow(normalizedWords, targetTokens);
    if (!bestMatch) return milestone;

    const matchedWord = allWords[bestMatch.startIndex];
    return {
      ...milestone,
      mappedTimestamp: matchedWord?.start ?? milestone.mappedTimestamp,
      confidence: Math.min(1, milestone.confidence * 0.5 + bestMatch.score * 0.5),
    };
  });
}

function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .trim();
}

interface WindowMatch {
  startIndex: number;
  score: number;
}

/**
 * Sliding-window token overlap search. This is intentionally simple
 * (O(n*m)) rather than pulling in a full alignment library — transcripts
 * for a single video are small enough that this runs in well under a
 * frame's worth of time, and it avoids a heavyweight NLP dependency for
 * what is fundamentally a fuzzy substring match.
 */
function findBestWindow(
  haystack: string[],
  needleTokens: string[]
): WindowMatch | null {
  const windowSize = needleTokens.length + WINDOW_PADDING_WORDS;
  let best: WindowMatch | null = null;

  for (let i = 0; i < haystack.length; i++) {
    const window = haystack.slice(i, i + windowSize);
    const overlap = countOverlap(window, needleTokens);
    const score = overlap / needleTokens.length;

    if (score > 0 && (!best || score > best.score)) {
      best = { startIndex: i, score };
    }
    if (score === 1) break; // perfect match, stop early
  }

  return best && best.score >= 0.35 ? best : null;
}

function countOverlap(window: string[], needle: string[]): number {
  const windowSet = new Set(window);
  return needle.filter((t) => windowSet.has(t)).length;
}
