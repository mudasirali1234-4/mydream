// ============================================================================
// Speech-to-Text Integration
// Wraps the Whisper transcription API to produce word-level timings, which
// power subtitle sync, karaoke-style text highlighting, and script alignment.
// ============================================================================

import type { TranscriptResult, TranscriptSegment, WordTiming } from '@/lib/types';
import { nanoid } from 'nanoid';

export interface TranscribeOptions {
  /** URL or blob of the extracted audio track (wav/mp3/m4a) */
  audioUrl: string;
  language?: string; // ISO 639-1, or 'auto'
}

interface WhisperVerboseSegment {
  id: number;
  start: number;
  end: number;
  text: string;
}

interface WhisperVerboseWord {
  word: string;
  start: number;
  end: number;
}

interface WhisperVerboseResponse {
  text: string;
  language: string;
  segments: WhisperVerboseSegment[];
  words?: WhisperVerboseWord[];
}

export async function transcribeAudio(
  opts: TranscribeOptions
): Promise<TranscriptResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'OPENAI_API_KEY not configured — required for Whisper transcription'
    );
  }

  const audioBlob = await fetchAsBlob(opts.audioUrl);
  const form = new FormData();
  form.append('file', audioBlob, 'audio.wav');
  form.append('model', 'whisper-1');
  form.append('response_format', 'verbose_json');
  form.append('timestamp_granularities[]', 'word');
  if (opts.language && opts.language !== 'auto') {
    form.append('language', opts.language);
  }

  const res = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Whisper transcription failed (${res.status}): ${errText}`);
  }

  const data = (await res.json()) as WhisperVerboseResponse;
  return normalizeWhisperResponse(data);
}

function normalizeWhisperResponse(data: WhisperVerboseResponse): TranscriptResult {
  const wordsByTime = data.words ?? [];

  const segments: TranscriptSegment[] = data.segments.map((seg) => {
    const words: WordTiming[] = wordsByTime
      .filter((w) => w.start >= seg.start && w.end <= seg.end + 0.05)
      .map((w) => ({ word: w.word.trim(), start: w.start, end: w.end }));

    return {
      id: nanoid(),
      start: seg.start,
      end: seg.end,
      text: seg.text.trim(),
      // Fall back to evenly-spaced word timings if Whisper didn't return
      // word-level granularity for this segment.
      words: words.length > 0 ? words : estimateWordTimings(seg),
    };
  });

  return { fullText: data.text, segments, language: data.language };
}

function estimateWordTimings(seg: WhisperVerboseSegment): WordTiming[] {
  const words = seg.text.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  const perWord = (seg.end - seg.start) / words.length;
  return words.map((word, i) => ({
    word,
    start: seg.start + i * perWord,
    end: seg.start + (i + 1) * perWord,
  }));
}

async function fetchAsBlob(url: string): Promise<Blob> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch audio for transcription: ${url}`);
  return res.blob();
}
