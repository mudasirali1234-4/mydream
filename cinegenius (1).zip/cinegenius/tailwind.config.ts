import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Core studio palette — deep obsidian workspace with a
        // signature "render orange" accent used sparingly for
        // active/AI states, and a cyan used for timeline playhead
        // and waveform accents.
        obsidian: {
          950: '#08090c',
          900: '#0d0f14',
          800: '#14161d',
          700: '#1c1f29',
          600: '#262a37',
          500: '#343948',
        },
        ember: {
          400: '#ff8a4c',
          500: '#ff6b1a',
          600: '#e6560c',
        },
        signal: {
          400: '#5ee9ff',
          500: '#22d3ee',
        },
        success: '#3ddc97',
        warn: '#ffcc4d',
        danger: '#ff5470',
      },
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 40px -10px rgba(255, 107, 26, 0.35)',
        panel: '0 4px 24px rgba(0,0,0,0.4)',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.6' },
          '50%': { opacity: '1' },
        },
        scan: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
      },
      animation: {
        pulseGlow: 'pulseGlow 2.4s ease-in-out infinite',
        scan: 'scan 1.8s linear infinite',
      },
    },
  },
  plugins: [],
};

export default config;
