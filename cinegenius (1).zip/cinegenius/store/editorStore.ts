'use client';

import { create } from 'zustand';
import { nanoid } from 'nanoid';
import type {
  Project,
  Track,
  Clip,
  TrackType,
  MediaAsset,
  ScriptAlignment,
} from '@/lib/types';

interface HistoryEntry {
  tracks: Track[];
  clips: Record<string, Clip>;
}

interface EditorState {
  project: Project | null;
  selectedClipIds: string[];
  playheadSec: number;
  isPlaying: boolean;
  zoomPxPerSec: number;
  history: HistoryEntry[];
  historyIndex: number;

  // --- Project lifecycle ---
  loadProject: (project: Project) => void;
  renameProject: (name: string) => void;

  // --- Tracks ---
  addTrack: (type: TrackType, name?: string) => string;
  removeTrack: (trackId: string) => void;
  toggleTrackVisibility: (trackId: string) => void;
  toggleTrackLock: (trackId: string) => void;

  // --- Clips ---
  addClip: (clip: Clip) => void;
  updateClip: (clipId: string, patch: Partial<Clip>) => void;
  moveClip: (clipId: string, newStart: number, newTrackId?: string) => void;
  splitClip: (clipId: string, atSec: number) => void;
  removeClip: (clipId: string) => void;
  selectClips: (clipIds: string[]) => void;

  // --- Assets ---
  addAsset: (asset: MediaAsset) => void;

  // --- AI ---
  setScriptAlignment: (alignment: ScriptAlignment) => void;

  // --- Playback ---
  setPlayhead: (sec: number) => void;
  setPlaying: (playing: boolean) => void;
  setZoom: (pxPerSec: number) => void;

  // --- History ---
  undo: () => void;
  redo: () => void;
  pushHistory: () => void;
}

const TRACK_LABEL: Record<TrackType, string> = {
  video: 'Video',
  audio: 'Audio',
  bgm: 'Music',
  subtitle: 'Subtitles',
  overlay3d: '3D Overlay',
  map: 'Map',
};

export const useEditorStore = create<EditorState>((set, get) => ({
  project: null,
  selectedClipIds: [],
  playheadSec: 0,
  isPlaying: false,
  zoomPxPerSec: 60,
  history: [],
  historyIndex: -1,

  loadProject: (project) => set({ project, history: [], historyIndex: -1 }),

  renameProject: (name) =>
    set((s) => (s.project ? { project: { ...s.project, name } } : s)),

  addTrack: (type, name) => {
    const id = nanoid();
    set((s) => {
      if (!s.project) return s;
      const order = s.project.tracks.length;
      const track: Track = {
        id,
        type,
        name: name ?? TRACK_LABEL[type],
        order,
        height: type === 'video' || type === 'overlay3d' ? 90 : 56,
        visible: true,
        locked: false,
        clipIds: [],
      };
      return {
        project: { ...s.project, tracks: [...s.project.tracks, track] },
      };
    });
    get().pushHistory();
    return id;
  },

  removeTrack: (trackId) =>
    set((s) => {
      if (!s.project) return s;
      const track = s.project.tracks.find((t) => t.id === trackId);
      if (!track) return s;
      const remainingClips = { ...s.project.clips };
      track.clipIds.forEach((cid) => delete remainingClips[cid]);
      return {
        project: {
          ...s.project,
          tracks: s.project.tracks.filter((t) => t.id !== trackId),
          clips: remainingClips,
        },
      };
    }),

  toggleTrackVisibility: (trackId) =>
    set((s) => {
      if (!s.project) return s;
      return {
        project: {
          ...s.project,
          tracks: s.project.tracks.map((t) =>
            t.id === trackId ? { ...t, visible: !t.visible } : t
          ),
        },
      };
    }),

  toggleTrackLock: (trackId) =>
    set((s) => {
      if (!s.project) return s;
      return {
        project: {
          ...s.project,
          tracks: s.project.tracks.map((t) =>
            t.id === trackId ? { ...t, locked: !t.locked } : t
          ),
        },
      };
    }),

  addClip: (clip) => {
    set((s) => {
      if (!s.project) return s;
      const tracks = s.project.tracks.map((t) =>
        t.id === clip.trackId ? { ...t, clipIds: [...t.clipIds, clip.id] } : t
      );
      return {
        project: {
          ...s.project,
          tracks,
          clips: { ...s.project.clips, [clip.id]: clip },
        },
      };
    });
    get().pushHistory();
  },

  updateClip: (clipId, patch) =>
    set((s) => {
      if (!s.project || !s.project.clips[clipId]) return s;
      const existing = s.project.clips[clipId];
      return {
        project: {
          ...s.project,
          clips: {
            ...s.project.clips,
            [clipId]: { ...existing, ...patch } as Clip,
          },
        },
      };
    }),

  moveClip: (clipId, newStart, newTrackId) => {
    set((s) => {
      if (!s.project) return s;
      const clip = s.project.clips[clipId];
      if (!clip) return s;
      let tracks = s.project.tracks;
      if (newTrackId && newTrackId !== clip.trackId) {
        tracks = tracks.map((t) => {
          if (t.id === clip.trackId)
            return { ...t, clipIds: t.clipIds.filter((id) => id !== clipId) };
          if (t.id === newTrackId)
            return { ...t, clipIds: [...t.clipIds, clipId] };
          return t;
        });
      }
      return {
        project: {
          ...s.project,
          tracks,
          clips: {
            ...s.project.clips,
            [clipId]: {
              ...clip,
              start: Math.max(0, newStart),
              trackId: newTrackId ?? clip.trackId,
            },
          },
        },
      };
    });
    get().pushHistory();
  },

  splitClip: (clipId, atSec) => {
    set((s) => {
      if (!s.project) return s;
      const clip = s.project.clips[clipId];
      if (!clip) return s;
      const localOffset = atSec - clip.start;
      if (localOffset <= 0 || localOffset >= clip.duration) return s;

      const firstHalf: Clip = { ...clip, duration: localOffset };
      const secondId = nanoid();
      const secondHalf: Clip = {
        ...clip,
        id: secondId,
        start: atSec,
        duration: clip.duration - localOffset,
        sourceIn: clip.sourceIn + localOffset, // all Clip variants extend BaseClip, which has sourceIn
      };

      const tracks = s.project.tracks.map((t) =>
        t.id === clip.trackId
          ? { ...t, clipIds: [...t.clipIds, secondId] }
          : t
      );

      return {
        project: {
          ...s.project,
          tracks,
          clips: {
            ...s.project.clips,
            [clipId]: firstHalf,
            [secondId]: secondHalf,
          },
        },
      };
    });
    get().pushHistory();
  },

  removeClip: (clipId) => {
    set((s) => {
      if (!s.project) return s;
      const clip = s.project.clips[clipId];
      if (!clip) return s;
      const remainingClips = { ...s.project.clips };
      delete remainingClips[clipId];
      return {
        project: {
          ...s.project,
          tracks: s.project.tracks.map((t) =>
            t.id === clip.trackId
              ? { ...t, clipIds: t.clipIds.filter((id) => id !== clipId) }
              : t
          ),
          clips: remainingClips,
        },
        selectedClipIds: s.selectedClipIds.filter((id) => id !== clipId),
      };
    });
    get().pushHistory();
  },

  selectClips: (clipIds) => set({ selectedClipIds: clipIds }),

  addAsset: (asset) =>
    set((s) =>
      s.project
        ? { project: { ...s.project, assets: [...s.project.assets, asset] } }
        : s
    ),

  setScriptAlignment: (alignment) =>
    set((s) =>
      s.project ? { project: { ...s.project, scriptAlignment: alignment } } : s
    ),

  setPlayhead: (sec) => set({ playheadSec: Math.max(0, sec) }),
  setPlaying: (playing) => set({ isPlaying: playing }),
  setZoom: (pxPerSec) => set({ zoomPxPerSec: Math.min(400, Math.max(10, pxPerSec)) }),

  pushHistory: () => {
    const { project, history, historyIndex } = get();
    if (!project) return;
    const entry: HistoryEntry = { tracks: project.tracks, clips: project.clips };
    const truncated = history.slice(0, historyIndex + 1);
    const nextHistory = [...truncated, entry].slice(-50); // cap at 50 states
    set({ history: nextHistory, historyIndex: nextHistory.length - 1 });
  },

  undo: () => {
    const { history, historyIndex, project } = get();
    if (historyIndex <= 0 || !project) return;
    const prev = history[historyIndex - 1];
    set({
      project: { ...project, tracks: prev.tracks, clips: prev.clips },
      historyIndex: historyIndex - 1,
    });
  },

  redo: () => {
    const { history, historyIndex, project } = get();
    if (historyIndex >= history.length - 1 || !project) return;
    const next = history[historyIndex + 1];
    set({
      project: { ...project, tracks: next.tracks, clips: next.clips },
      historyIndex: historyIndex + 1,
    });
  },
}));
