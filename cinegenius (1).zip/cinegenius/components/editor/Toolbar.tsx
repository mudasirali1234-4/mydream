'use client';

import Link from 'next/link';
import { useEditorStore } from '@/store/editorStore';
import { ArrowLeft, Undo2, Redo2, Download, Image as ImageIcon } from 'lucide-react';
import { useState } from 'react';

export default function Toolbar() {
  const project = useEditorStore((s) => s.project);
  const renameProject = useEditorStore((s) => s.renameProject);
  const undo = useEditorStore((s) => s.undo);
  const redo = useEditorStore((s) => s.redo);
  const [isRendering, setIsRendering] = useState(false);

  if (!project) return null;

  async function handleExport() {
    setIsRendering(true);
    try {
      const res = await fetch('/api/render', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          target: { resolution: '1080p', format: 'mp4', quality: 'standard' },
        }),
      });
      const job = await res.json();
      // In production: poll GET /api/render/:jobId or subscribe via websocket
      // for progress, then surface a download link when job.status === 'complete'.
      console.log('Render job queued:', job);
    } finally {
      setIsRendering(false);
    }
  }

  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
      <div className="flex items-center gap-3">
        <Link href="/dashboard" className="icon-btn">
          <ArrowLeft size={16} />
        </Link>
        <input
          value={project.name}
          onChange={(e) => renameProject(e.target.value)}
          className="bg-transparent font-display font-semibold text-sm focus:outline-none focus:bg-white/5 rounded px-2 py-1 -ml-2"
        />
      </div>

      <div className="flex items-center gap-2">
        <button className="icon-btn" onClick={undo} title="Undo">
          <Undo2 size={15} />
        </button>
        <button className="icon-btn" onClick={redo} title="Redo">
          <Redo2 size={15} />
        </button>
        <Link href={`/editor/${project.id}/thumbnails`} className="btn-secondary flex items-center gap-2 text-sm">
          <ImageIcon size={14} /> Thumbnails
        </Link>
        <button
          onClick={handleExport}
          disabled={isRendering}
          className="btn-primary flex items-center gap-2 text-sm"
        >
          <Download size={14} /> {isRendering ? 'Queuing...' : 'Export'}
        </button>
      </div>
    </div>
  );
}
