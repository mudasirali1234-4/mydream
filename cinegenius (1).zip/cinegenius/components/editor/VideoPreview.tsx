'use client';

import { useEffect, useRef } from 'react';
import { useEditorStore } from '@/store/editorStore';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';

export default function VideoPreview() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const project = useEditorStore((s) => s.project);
  const playheadSec = useEditorStore((s) => s.playheadSec);
  const isPlaying = useEditorStore((s) => s.isPlaying);
  const setPlaying = useEditorStore((s) => s.setPlaying);
  const setPlayhead = useEditorStore((s) => s.setPlayhead);

  // Keep the <video> element in sync with the store's playhead, without
  // fighting the browser's own timeupdate loop while actively playing.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (Math.abs(video.currentTime - playheadSec) > 0.15) {
      video.currentTime = playheadSec;
    }
  }, [playheadSec]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) video.play().catch(() => setPlaying(false));
    else video.pause();
  }, [isPlaying, setPlaying]);

  const activeVideoClip = getActiveVideoClip(project, playheadSec);

  return (
    <div className="flex flex-col h-full">
      <div className="relative flex-1 bg-black rounded-xl overflow-hidden flex items-center justify-center">
        {activeVideoClip ? (
          <video
            ref={videoRef}
            src={activeVideoClip.url}
            className="max-h-full max-w-full"
            onTimeUpdate={(e) => {
              if (isPlaying) setPlayhead(e.currentTarget.currentTime);
            }}
            onEnded={() => setPlaying(false)}
          />
        ) : (
          <div className="text-white/20 text-sm">No clip at playhead</div>
        )}

        {/* Subtitle overlay */}
        {project && (
          <SubtitleOverlay projectId={project.id} playheadSec={playheadSec} />
        )}
      </div>

      <div className="flex items-center justify-center gap-3 py-3">
        <button
          className="icon-btn"
          onClick={() => setPlayhead(Math.max(0, playheadSec - 5))}
        >
          <SkipBack size={16} />
        </button>
        <button
          className="w-11 h-11 rounded-full bg-white text-obsidian-950 flex items-center justify-center hover:scale-105 transition-transform"
          onClick={() => setPlaying(!isPlaying)}
        >
          {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
        </button>
        <button
          className="icon-btn"
          onClick={() => setPlayhead(playheadSec + 5)}
        >
          <SkipForward size={16} />
        </button>
        <span className="ml-3 font-mono text-xs text-white/50 tabular-nums">
          {formatTimecode(playheadSec)}
        </span>
      </div>
    </div>
  );
}

function getActiveVideoClip(
  project: ReturnType<typeof useEditorStore.getState>['project'],
  playheadSec: number
): { url: string } | null {
  if (!project) return null;
  const clip = Object.values(project.clips).find(
    (c) =>
      c.type === 'video' &&
      playheadSec >= c.start &&
      playheadSec < c.start + c.duration
  );
  if (!clip || clip.type !== 'video') return null;
  const asset = project.assets.find((a) => a.id === clip.assetId);
  return asset ? { url: asset.url } : null;
}

function SubtitleOverlay({ playheadSec }: { projectId: string; playheadSec: number }) {
  const project = useEditorStore((s) => s.project);
  if (!project) return null;

  const active = Object.values(project.clips).find(
    (c) =>
      c.type === 'subtitle' &&
      playheadSec >= c.start &&
      playheadSec < c.start + c.duration
  );
  if (!active || active.type !== 'subtitle') return null;

  return (
    <div
      className="absolute left-0 right-0 bottom-8 flex justify-center px-8 pointer-events-none"
      style={{ color: active.style.color }}
    >
      <span
        className="font-bold text-2xl text-center leading-snug"
        style={{
          textShadow: '0 2px 8px rgba(0,0,0,0.8)',
          backgroundColor: `rgba(0,0,0,${active.style.bgOpacity})`,
          padding: active.style.bgOpacity > 0 ? '4px 10px' : 0,
          borderRadius: 6,
        }}
      >
        {renderWords(active)}
      </span>
    </div>
  );
}

function renderWords(clip: { text: string; words?: { word: string }[]; style: { highlightColor: string } }) {
  if (!clip.words || clip.words.length === 0) return clip.text;
  return clip.words.map((w, i) => (
    <span key={i} style={{ color: clip.style.highlightColor }} className="mx-0.5">
      {w.word}
    </span>
  ));
}

function formatTimecode(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  const f = Math.floor((sec % 1) * 30);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}:${f
    .toString()
    .padStart(2, '0')}`;
}
