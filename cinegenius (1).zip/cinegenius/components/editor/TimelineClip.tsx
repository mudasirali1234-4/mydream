'use client';

import { useRef, useState } from 'react';
import type { Clip } from '@/lib/types';
import { useEditorStore } from '@/store/editorStore';

interface TimelineClipProps {
  clip: Clip;
  pxPerSec: number;
  trackHeight: number;
}

const TRACK_COLOR: Record<Clip['type'], string> = {
  video: 'from-signal-500/80 to-signal-500/40 border-signal-400',
  audio: 'from-emerald-500/70 to-emerald-500/30 border-emerald-400',
  bgm: 'from-purple-500/70 to-purple-500/30 border-purple-400',
  subtitle: 'from-ember-500/80 to-ember-500/40 border-ember-400',
  overlay3d: 'from-pink-500/70 to-pink-500/30 border-pink-400',
  map: 'from-teal-500/70 to-teal-500/30 border-teal-400',
};

export default function TimelineClip({ clip, pxPerSec, trackHeight }: TimelineClipProps) {
  const moveClip = useEditorStore((s) => s.moveClip);
  const selectClips = useEditorStore((s) => s.selectClips);
  const selectedClipIds = useEditorStore((s) => s.selectedClipIds);
  const isSelected = selectedClipIds.includes(clip.id);

  const dragState = useRef<{ startX: number; originalStart: number } | null>(null);
  const [dragOffsetPx, setDragOffsetPx] = useState(0);

  function onMouseDown(e: React.MouseEvent) {
    e.stopPropagation();
    selectClips([clip.id]);
    dragState.current = { startX: e.clientX, originalStart: clip.start };

    function onMouseMove(ev: MouseEvent) {
      if (!dragState.current) return;
      const deltaPx = ev.clientX - dragState.current.startX;
      setDragOffsetPx(deltaPx);
    }

    function onMouseUp(ev: MouseEvent) {
      if (dragState.current) {
        const deltaSec = (ev.clientX - dragState.current.startX) / pxPerSec;
        const newStart = Math.max(0, dragState.current.originalStart + deltaSec);
        moveClip(clip.id, roundToFrame(newStart));
      }
      dragState.current = null;
      setDragOffsetPx(0);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    }

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  }

  const left = clip.start * pxPerSec + dragOffsetPx;
  const width = Math.max(4, clip.duration * pxPerSec);

  return (
    <div
      onMouseDown={onMouseDown}
      className={`absolute top-1 rounded-md border bg-gradient-to-b cursor-grab active:cursor-grabbing select-none
        ${TRACK_COLOR[clip.type]} ${isSelected ? 'ring-2 ring-white/80 z-10' : 'z-0'}`}
      style={{ left, width, height: trackHeight - 8 }}
    >
      <div className="px-2 py-1 h-full flex flex-col justify-center overflow-hidden">
        <span className="text-[11px] font-medium text-white truncate leading-tight">
          {clip.label || defaultLabel(clip)}
        </span>
        {clip.type === 'video' && clip.speed !== 1 && (
          <span className="text-[9px] text-white/70 font-mono">{clip.speed}x</span>
        )}
      </div>
    </div>
  );
}

function defaultLabel(clip: Clip): string {
  switch (clip.type) {
    case 'subtitle':
      return clip.text.slice(0, 24);
    case 'map':
      return 'Map route';
    case 'overlay3d':
      return '3D overlay';
    default:
      return clip.type;
  }
}

function roundToFrame(sec: number, fps = 30): number {
  return Math.round(sec * fps) / fps;
}
