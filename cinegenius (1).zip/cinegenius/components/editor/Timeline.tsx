'use client';

import { useRef } from 'react';
import { useEditorStore } from '@/store/editorStore';
import TimelineTrack from './TimelineTrack';
import { Plus, ZoomIn, ZoomOut } from 'lucide-react';
import type { TrackType } from '@/lib/types';

const ADDABLE_TRACKS: { type: TrackType; label: string }[] = [
  { type: 'video', label: 'Video Track' },
  { type: 'audio', label: 'Audio Track' },
  { type: 'bgm', label: 'Music Track' },
  { type: 'subtitle', label: 'Subtitle Track' },
  { type: 'overlay3d', label: '3D Overlay Track' },
  { type: 'map', label: 'Map Track' },
];

export default function Timeline() {
  const project = useEditorStore((s) => s.project);
  const zoomPxPerSec = useEditorStore((s) => s.zoomPxPerSec);
  const setZoom = useEditorStore((s) => s.setZoom);
  const playheadSec = useEditorStore((s) => s.playheadSec);
  const setPlayhead = useEditorStore((s) => s.setPlayhead);
  const addTrack = useEditorStore((s) => s.addTrack);

  const scrollRef = useRef<HTMLDivElement>(null);

  if (!project) return null;

  const durationSec = Math.max(project.durationSec, 60);
  const timelineWidth = durationSec * zoomPxPerSec;

  function handleRulerClick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left + (scrollRef.current?.scrollLeft ?? 0) - 160; // offset track header
    setPlayhead(Math.max(0, x / zoomPxPerSec));
  }

  const sortedTracks = [...project.tracks].sort((a, b) => a.order - b.order);

  return (
    <div className="flex flex-col h-full glass-panel rounded-xl overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/5">
        <div className="flex items-center gap-1">
          {ADDABLE_TRACKS.map((t) => (
            <button
              key={t.type}
              onClick={() => addTrack(t.type)}
              className="text-[11px] px-2 py-1 rounded-md text-white/50 hover:text-white hover:bg-white/5 flex items-center gap-1"
              title={`Add ${t.label}`}
            >
              <Plus size={10} /> {t.label.split(' ')[0]}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          <button className="icon-btn !w-7 !h-7" onClick={() => setZoom(zoomPxPerSec - 20)}>
            <ZoomOut size={13} />
          </button>
          <button className="icon-btn !w-7 !h-7" onClick={() => setZoom(zoomPxPerSec + 20)}>
            <ZoomIn size={13} />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-auto relative">
        {/* Ruler */}
        <div
          className="h-7 sticky top-0 z-30 bg-obsidian-800 border-b border-white/5 flex cursor-pointer"
          style={{ width: timelineWidth + 160 }}
          onClick={handleRulerClick}
        >
          <div className="w-40 shrink-0 sticky left-0 bg-obsidian-800 z-10" />
          <div className="relative flex-1">
            {buildRulerMarks(durationSec, zoomPxPerSec).map((mark) => (
              <span
                key={mark.sec}
                className="absolute top-1.5 text-[10px] font-mono text-white/30"
                style={{ left: mark.sec * zoomPxPerSec }}
              >
                {mark.label}
              </span>
            ))}
          </div>
        </div>

        {/* Playhead line */}
        <div
          className="absolute top-7 bottom-0 w-px bg-ember-500 z-30 pointer-events-none"
          style={{ left: 160 + playheadSec * zoomPxPerSec }}
        >
          <div className="w-2.5 h-2.5 rounded-full bg-ember-500 -ml-[5px] -mt-1" />
        </div>

        {/* Tracks */}
        <div style={{ width: timelineWidth + 160 }}>
          {sortedTracks.map((track) => (
            <TimelineTrack
              key={track.id}
              track={track}
              clips={track.clipIds.map((id) => project.clips[id]).filter(Boolean)}
              pxPerSec={zoomPxPerSec}
            />
          ))}
          {sortedTracks.length === 0 && (
            <div className="p-10 text-center text-white/30 text-sm">
              Add a track above to start building your timeline.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function buildRulerMarks(durationSec: number, pxPerSec: number) {
  const stepSec = pxPerSec < 40 ? 10 : pxPerSec < 100 ? 5 : 1;
  const marks: { sec: number; label: string }[] = [];
  for (let s = 0; s <= durationSec; s += stepSec) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    marks.push({ sec: s, label: `${m}:${sec.toString().padStart(2, '0')}` });
  }
  return marks;
}
