'use client';

import type { Track, Clip } from '@/lib/types';
import { Eye, EyeOff, Lock, Unlock, Video, Music2, Type, Box, MapIcon } from 'lucide-react';
import TimelineClip from './TimelineClip';
import { useEditorStore } from '@/store/editorStore';

interface TimelineTrackProps {
  track: Track;
  clips: Clip[];
  pxPerSec: number;
}

const TRACK_ICON: Record<Track['type'], typeof Video> = {
  video: Video,
  audio: Music2,
  bgm: Music2,
  subtitle: Type,
  overlay3d: Box,
  map: MapIcon,
};

export default function TimelineTrack({ track, clips, pxPerSec }: TimelineTrackProps) {
  const toggleTrackVisibility = useEditorStore((s) => s.toggleTrackVisibility);
  const toggleTrackLock = useEditorStore((s) => s.toggleTrackLock);
  const Icon = TRACK_ICON[track.type];

  return (
    <div className="flex border-b border-white/5" style={{ height: track.height }}>
      {/* Track header */}
      <div className="w-40 shrink-0 flex items-center gap-2 px-3 bg-obsidian-800 border-r border-white/5 sticky left-0 z-20">
        <Icon size={13} className="text-white/40 shrink-0" />
        <span className="text-xs text-white/70 truncate flex-1">{track.name}</span>
        <button
          className="icon-btn !w-6 !h-6"
          onClick={() => toggleTrackVisibility(track.id)}
          title="Toggle visibility"
        >
          {track.visible ? <Eye size={12} /> : <EyeOff size={12} className="text-white/30" />}
        </button>
        <button
          className="icon-btn !w-6 !h-6"
          onClick={() => toggleTrackLock(track.id)}
          title="Toggle lock"
        >
          {track.locked ? <Lock size={12} className="text-ember-400" /> : <Unlock size={12} />}
        </button>
      </div>

      {/* Track lane */}
      <div className="relative flex-1 timeline-grid" style={{ backgroundSize: `${pxPerSec}px 100%` }}>
        {clips.map((clip) => (
          <TimelineClip key={clip.id} clip={clip} pxPerSec={pxPerSec} trackHeight={track.height} />
        ))}
      </div>
    </div>
  );
}
