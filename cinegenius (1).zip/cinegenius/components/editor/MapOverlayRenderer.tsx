'use client';

// ============================================================================
// Dynamic Map Graphics
// Renders an animated route/marker overlay using Mapbox GL. As the local
// clip time advances, the route line is progressively drawn (using a
// line-layer with a dynamically clipped GeoJSON) to create a "travel replay"
// effect synced to the video timeline.
// ============================================================================

import { useEffect, useMemo, useRef } from 'react';
import Map, { Source, Layer, Marker, MapRef } from 'react-map-gl';
import type { MapClip } from '@/lib/types';
import { MapPin } from 'lucide-react';

const MAPBOX_STYLES: Record<MapClip['style'], string> = {
  satellite: 'mapbox://styles/mapbox/satellite-streets-v12',
  streets: 'mapbox://styles/mapbox/streets-v12',
  dark: 'mapbox://styles/mapbox/dark-v11',
  terrain: 'mapbox://styles/mapbox/outdoors-v12',
};

interface MapOverlayRendererProps {
  clip: MapClip;
  /** Seconds elapsed since this clip's `start` */
  localTimeSec: number;
}

export default function MapOverlayRenderer({ clip, localTimeSec }: MapOverlayRendererProps) {
  const mapRef = useRef<MapRef>(null);

  const progressRatio = clip.animateRoute
    ? Math.min(1, localTimeSec / clip.duration)
    : 1;

  const visiblePoints = useMemo(() => {
    if (!clip.animateRoute) return clip.route;
    const count = Math.max(2, Math.ceil(clip.route.length * progressRatio));
    return clip.route.slice(0, count);
  }, [clip.route, clip.animateRoute, progressRatio]);

  const routeGeoJson = useMemo(
    () => ({
      type: 'Feature' as const,
      geometry: {
        type: 'LineString' as const,
        coordinates: visiblePoints.map((p) => [p.lng, p.lat]),
      },
      properties: {},
    }),
    [visiblePoints]
  );

  const center = clip.route[0] ?? { lat: 0, lng: 0 };

  useEffect(() => {
    if (!mapRef.current || visiblePoints.length === 0) return;
    const last = visiblePoints[visiblePoints.length - 1];
    mapRef.current.easeTo({ center: [last.lng, last.lat], duration: 200 });
  }, [visiblePoints]);

  return (
    <div className="absolute inset-0 pointer-events-none rounded-xl overflow-hidden">
      <Map
        ref={mapRef}
        mapboxAccessToken={process.env.NEXT_PUBLIC_MAPBOX_TOKEN}
        initialViewState={{ longitude: center.lng, latitude: center.lat, zoom: 9 }}
        mapStyle={MAPBOX_STYLES[clip.style]}
        interactive={false}
        attributionControl={false}
      >
        <Source id="route" type="geojson" data={routeGeoJson}>
          <Layer
            id="route-line"
            type="line"
            paint={{
              'line-color': '#ff6b1a',
              'line-width': 4,
              'line-opacity': 0.9,
            }}
          />
        </Source>

        {clip.markers?.map((m, i) => (
          <Marker key={i} longitude={m.point.lng} latitude={m.point.lat}>
            <div className="flex flex-col items-center">
              <MapPin size={18} className="text-ember-500 drop-shadow" fill="currentColor" />
              <span className="text-[10px] font-medium bg-black/70 text-white px-1.5 py-0.5 rounded mt-0.5">
                {m.label}
              </span>
            </div>
          </Marker>
        ))}
      </Map>
    </div>
  );
}
