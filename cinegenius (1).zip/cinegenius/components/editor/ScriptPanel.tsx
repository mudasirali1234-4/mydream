'use client';

import { useState } from 'react';
import { useEditorStore } from '@/store/editorStore';
import type { ScriptMilestone } from '@/lib/types';
import { Sparkles, Loader2, Target } from 'lucide-react';

const BEAT_COLOR: Record<ScriptMilestone['beatType'], string> = {
  hook: 'bg-signal-500/20 text-signal-400 border-signal-500/30',
  claim: 'bg-white/10 text-white/70 border-white/20',
  evidence: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  'emotional-peak': 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  'call-to-action': 'bg-ember-500/20 text-ember-400 border-ember-500/30',
  transition: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  punchline: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
};

export default function ScriptPanel() {
  const project = useEditorStore((s) => s.project);
  const setScriptAlignment = useEditorStore((s) => s.setScriptAlignment);
  const setPlayhead = useEditorStore((s) => s.setPlayhead);
  const [scriptText, setScriptText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const milestones = project?.scriptAlignment?.milestones ?? [];

  async function handleAnalyze() {
    if (!scriptText.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const res = await fetch('/api/parse-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: scriptText, style: 'high-retention' }),
      });
      if (!res.ok) throw new Error(`Analysis failed (${res.status})`);
      const { milestones: parsed } = await res.json();
      setScriptAlignment({
        documentId: `doc_${Date.now()}`,
        milestones: parsed,
        alignedAt: new Date().toISOString(),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setIsAnalyzing(false);
    }
  }

  return (
    <div className="flex flex-col h-full glass-panel rounded-xl p-4 overflow-hidden">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={15} className="text-ember-400" />
        <h2 className="font-display font-semibold text-sm">Script Alignment</h2>
      </div>

      <textarea
        value={scriptText}
        onChange={(e) => setScriptText(e.target.value)}
        placeholder="Paste your script or narration text here..."
        className="w-full h-28 bg-obsidian-900 border border-white/10 rounded-lg p-3 text-xs text-white/80 resize-none focus:outline-none focus:border-ember-500/50"
      />

      <button
        onClick={handleAnalyze}
        disabled={isAnalyzing || !scriptText.trim()}
        className="btn-primary mt-3 w-full flex items-center justify-center gap-2 text-sm py-2"
      >
        {isAnalyzing ? (
          <>
            <Loader2 size={14} className="animate-spin" /> Analyzing narrative beats...
          </>
        ) : (
          'Extract milestones'
        )}
      </button>

      {error && <p className="text-xs text-danger mt-2">{error}</p>}

      <div className="mt-4 flex-1 overflow-y-auto no-scrollbar space-y-2">
        {milestones.map((m) => (
          <button
            key={m.id}
            onClick={() => m.mappedTimestamp !== undefined && setPlayhead(m.mappedTimestamp)}
            className="w-full text-left rounded-lg border border-white/5 bg-obsidian-800/60 p-2.5 hover:border-white/15 transition-colors"
          >
            <div className="flex items-center justify-between mb-1">
              <span
                className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border ${BEAT_COLOR[m.beatType]}`}
              >
                {m.beatType}
              </span>
              {m.mappedTimestamp !== undefined && (
                <span className="flex items-center gap-1 text-[10px] text-white/40 font-mono">
                  <Target size={9} /> {formatSec(m.mappedTimestamp)}
                </span>
              )}
            </div>
            <p className="text-xs text-white/60 line-clamp-2">{m.excerpt}</p>
            <p className="text-[10px] text-white/30 mt-1">
              Suggested: {m.suggestedAction.kind.replace('-', ' ')}
            </p>
          </button>
        ))}
        {milestones.length === 0 && !isAnalyzing && (
          <p className="text-xs text-white/25 text-center pt-6">
            No milestones yet — paste a script above and extract beats.
          </p>
        )}
      </div>
    </div>
  );
}

function formatSec(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}
