'use client';

// ============================================================================
// 3D Animation Overlay
// Renders a .glb/.gltf model on a transparent WebGL canvas positioned above
// the video preview. Position/rotation/scale and entrance animation are
// driven by the corresponding Overlay3DClip on the timeline, so scrubbing
// the playhead scrubs the 3D animation in lockstep with the footage.
// ============================================================================

import { Suspense, useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useGLTF, Environment } from '@react-three/drei';
import type { Overlay3DClip } from '@/lib/types';
import * as THREE from 'three';

interface Overlay3DRendererProps {
  clip: Overlay3DClip;
  /** Seconds elapsed since this clip's `start`, drives entrance/animation */
  localTimeSec: number;
}

export default function Overlay3DRenderer({ clip, localTimeSec }: Overlay3DRendererProps) {
  return (
    <div className="absolute inset-0 pointer-events-none">
      <Canvas
        gl={{ alpha: true, antialias: true }}
        camera={{ position: [0, 0, 5], fov: 45 }}
        style={{ background: 'transparent' }}
      >
        <ambientLight intensity={0.6} />
        <directionalLight position={[3, 5, 2]} intensity={1.2} />
        <Suspense fallback={null}>
          <Environment preset="city" />
          <Model clip={clip} localTimeSec={localTimeSec} />
        </Suspense>
      </Canvas>
    </div>
  );
}

function Model({ clip, localTimeSec }: Overlay3DRendererProps) {
  const { scene, animations } = useGLTF(clip.modelUrl);
  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  const groupRef = useRef<THREE.Group>(null);

  useEffect(() => {
    if (animations.length === 0) return;
    const mixer = new THREE.AnimationMixer(scene);
    const clipAnim =
      animations.find((a) => a.name === clip.animationClip) ?? animations[0];
    mixer.clipAction(clipAnim).play();
    mixerRef.current = mixer;
    return () => mixer.stopAllAction();
  }, [scene, animations, clip.animationClip]);

  useFrame((_, delta) => {
    mixerRef.current?.update(delta);

    if (groupRef.current) {
      const entranceScale = computeEntranceScale(clip.entrance, localTimeSec);
      groupRef.current.scale.set(
        clip.scale.x * entranceScale,
        clip.scale.y * entranceScale,
        clip.scale.z * entranceScale
      );
    }
  });

  return (
    <group
      ref={groupRef}
      position={[clip.position.x, clip.position.y, clip.position.z]}
      rotation={[clip.rotation.x, clip.rotation.y, clip.rotation.z]}
    >
      <primitive object={scene} />
    </group>
  );
}

function computeEntranceScale(
  entrance: Overlay3DClip['entrance'],
  localTimeSec: number
): number {
  const ENTRANCE_DURATION = 0.4;
  const t = Math.min(1, Math.max(0, localTimeSec / ENTRANCE_DURATION));

  switch (entrance) {
    case 'pop':
      // overshoot-and-settle easing for a punchy "pop"
      return t < 1 ? easeOutBack(t) : 1;
    case 'fade':
    case 'slide':
      return t < 1 ? t : 1;
    case 'none':
    default:
      return 1;
  }
}

function easeOutBack(t: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}
