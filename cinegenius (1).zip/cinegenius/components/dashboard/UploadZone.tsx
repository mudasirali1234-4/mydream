'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, FileText, Film, CheckCircle2 } from 'lucide-react';

interface UploadZoneProps {
  onFilesAccepted: (files: File[]) => void;
}

export default function UploadZone({ onFilesAccepted }: UploadZoneProps) {
  const [recentlyAdded, setRecentlyAdded] = useState<string[]>([]);

  const onDrop = useCallback(
    (accepted: File[]) => {
      setRecentlyAdded(accepted.map((f) => f.name));
      onFilesAccepted(accepted);
    },
    [onFilesAccepted]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.webm', '.mkv'],
      'audio/*': ['.mp3', '.wav', '.m4a'],
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
  });

  return (
    <div
      {...getRootProps()}
      className={`relative rounded-2xl border-2 border-dashed p-10 text-center cursor-pointer transition-colors duration-200 ${
        isDragActive
          ? 'border-ember-500 bg-ember-500/5'
          : 'border-white/10 hover:border-white/20 bg-obsidian-800/50'
      }`}
    >
      <input {...getInputProps()} />
      <div className="flex justify-center gap-3 mb-4">
        <div className="w-11 h-11 rounded-xl bg-obsidian-700 flex items-center justify-center">
          <Film size={18} className="text-signal-400" />
        </div>
        <div className="w-11 h-11 rounded-xl bg-obsidian-700 flex items-center justify-center">
          <FileText size={18} className="text-ember-400" />
        </div>
      </div>
      <UploadCloud size={22} className="mx-auto mb-3 text-white/30" />
      <p className="font-medium text-white/85">
        {isDragActive ? 'Drop to upload' : 'Drag footage or scripts here'}
      </p>
      <p className="text-sm text-white/40 mt-1">
        Video (.mp4, .mov), audio, or documents (.txt, .pdf, .docx)
      </p>

      {recentlyAdded.length > 0 && (
        <ul className="mt-5 flex flex-col gap-1.5 text-left max-w-sm mx-auto">
          {recentlyAdded.map((name) => (
            <li
              key={name}
              className="flex items-center gap-2 text-sm text-white/60 bg-obsidian-700/60 rounded-lg px-3 py-2"
            >
              <CheckCircle2 size={14} className="text-success shrink-0" />
              <span className="truncate">{name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
