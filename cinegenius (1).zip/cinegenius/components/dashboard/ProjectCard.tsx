import Link from 'next/link';
import { Clock, Film } from 'lucide-react';

interface ProjectCardProps {
  id: string;
  name: string;
  updatedAt: string;
  durationSec: number;
  thumbnailUrl?: string;
}

export default function ProjectCard({
  id,
  name,
  updatedAt,
  durationSec,
  thumbnailUrl,
}: ProjectCardProps) {
  return (
    <Link
      href={`/editor/${id}`}
      className="group rounded-xl overflow-hidden glass-panel hover:border-ember-500/40 transition-colors duration-200"
    >
      <div className="aspect-video bg-obsidian-700 relative overflow-hidden">
        {thumbnailUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={thumbnailUrl}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white/20">
            <Film size={28} />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      <div className="p-4">
        <h3 className="font-medium text-sm truncate">{name}</h3>
        <div className="flex items-center gap-3 mt-2 text-xs text-white/40">
          <span className="flex items-center gap-1">
            <Clock size={11} /> {formatDuration(durationSec)}
          </span>
          <span>Updated {formatRelative(updatedAt)}</span>
        </div>
      </div>
    </Link>
  );
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatRelative(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const diffH = Math.floor(diffMs / 3600000);
  if (diffH < 1) return 'just now';
  if (diffH < 24) return `${diffH}h ago`;
  return `${Math.floor(diffH / 24)}d ago`;
}
