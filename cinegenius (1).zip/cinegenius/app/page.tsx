import Link from 'next/link';
import {
  Film,
  Wand2,
  Map,
  Box,
  Mic,
  Image as ImageIcon,
  ArrowRight,
} from 'lucide-react';

const FEATURES = [
  {
    icon: Wand2,
    title: 'Document-to-Video Engine',
    body: 'Upload a script or research doc. CineGenius extracts hooks, evidence, and emotional peaks, then maps every beat to a timestamp in your raw footage.',
  },
  {
    icon: Mic,
    title: 'Word-Level Transcription',
    body: 'Whisper-grade speech-to-text drives karaoke-style subtitle highlighting synced to the exact syllable.',
  },
  {
    icon: Film,
    title: 'Automated Editing Actions',
    body: 'Smart cuts, slow-motion ramps, and zoom-punches fire automatically on the narrative beats that earn them.',
  },
  {
    icon: Box,
    title: '3D Overlay Engine',
    body: 'Drop in animated 3D elements with full position, rotation, and entrance control — no separate compositor needed.',
  },
  {
    icon: Map,
    title: 'Dynamic Map Graphics',
    body: 'Animated route reveals and geographic call-outs render directly on the timeline.',
  },
  {
    icon: ImageIcon,
    title: 'High-CTR Thumbnails',
    body: 'Frame scoring surfaces your most click-worthy moments; typography composites them automatically.',
  },
];

export default function LandingPage() {
  return (
    <main className="relative overflow-hidden">
      {/* ambient scan line — signature element referencing script/audio alignment */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-40">
        <div className="absolute top-1/3 left-0 right-0 h-px bg-gradient-to-r from-transparent via-ember-500 to-transparent animate-scan" />
      </div>

      <nav className="relative z-10 flex items-center justify-between px-8 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-gradient-to-br from-ember-400 to-ember-600 flex items-center justify-center">
            <Film size={16} strokeWidth={2.5} />
          </div>
          <span className="font-display font-bold text-lg tracking-tight">
            CineGenius
          </span>
        </div>
        <Link href="/dashboard" className="btn-primary flex items-center gap-2">
          Open Studio <ArrowRight size={16} />
        </Link>
      </nav>

      <section className="relative z-10 max-w-5xl mx-auto px-8 pt-20 pb-28 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs font-mono text-signal-400 mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-signal-400 animate-pulseGlow" />
          SCRIPT → TIMESTAMP ALIGNMENT: LIVE
        </div>
        <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
          Raw footage in.
          <br />
          <span className="bg-gradient-to-r from-ember-400 to-ember-600 bg-clip-text text-transparent">
            Cinematic retention
          </span>{' '}
          out.
        </h1>
        <p className="mt-6 text-lg text-white/60 max-w-2xl mx-auto">
          CineGenius reads your script the way your editor does — finding the
          hook, the punchline, the beat that needs to slow down — and builds
          the cut around it automatically.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <Link href="/dashboard" className="btn-primary text-base px-6 py-3">
            Start a project
          </Link>
          <a href="#features" className="btn-secondary text-base px-6 py-3">
            See how it works
          </a>
        </div>
      </section>

      <section id="features" className="relative z-10 max-w-6xl mx-auto px-8 pb-32">
        <div className="grid md:grid-cols-3 gap-5">
          {FEATURES.map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="glass-panel rounded-2xl p-6 hover:border-ember-500/30 transition-colors duration-200"
            >
              <div className="w-10 h-10 rounded-lg bg-ember-500/10 flex items-center justify-center mb-4">
                <Icon size={18} className="text-ember-400" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">{title}</h3>
              <p className="text-sm text-white/55 leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/5 py-8 text-center text-xs text-white/30">
        CineGenius — built for creators who cut for retention.
      </footer>
    </main>
  );
}
