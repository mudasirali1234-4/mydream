'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { nanoid } from 'nanoid';
import { Plus } from 'lucide-react';
import UploadZone from '@/components/dashboard/UploadZone';
import ProjectCard from '@/components/dashboard/ProjectCard';

// Placeholder in-memory project list. Wire this up to your DB
// (Postgres/Prisma, Supabase, etc.) via a server action or API route.
const MOCK_PROJECTS = [
  {
    id: 'proj_demo_1',
    name: 'Why Empires Collapse — Ep. 4',
    updatedAt: new Date(Date.now() - 3 * 3600_000).toISOString(),
    durationSec: 612,
  },
  {
    id: 'proj_demo_2',
    name: '24 Hours in the Sahara',
    updatedAt: new Date(Date.now() - 26 * 3600_000).toISOString(),
    durationSec: 845,
  },
];

export default function DashboardPage() {
  const router = useRouter();
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);

  function handleFilesAccepted(files: File[]) {
    setPendingFiles((prev) => [...prev, ...files]);
  }

  function handleCreateProject() {
    // In production: upload `pendingFiles` to storage, create the project
    // record server-side, then route to the fresh editor with real asset IDs.
    const id = `proj_${nanoid(8)}`;
    router.push(`/editor/${id}`);
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-white/5 px-8 py-5 flex items-center justify-between">
        <h1 className="font-display text-xl font-bold">Your Studio</h1>
        <button onClick={handleCreateProject} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> New Project
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-8 py-10">
        <section className="mb-12">
          <UploadZone onFilesAccepted={handleFilesAccepted} />
          {pendingFiles.length > 0 && (
            <div className="mt-4 flex justify-end">
              <button onClick={handleCreateProject} className="btn-primary">
                Create project with {pendingFiles.length} file
                {pendingFiles.length > 1 ? 's' : ''}
              </button>
            </div>
          )}
        </section>

        <section>
          <h2 className="text-sm font-medium text-white/50 mb-4 uppercase tracking-wide">
            Recent Projects
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {MOCK_PROJECTS.map((p) => (
              <ProjectCard key={p.id} {...p} />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
