'use client';

import { useEffect } from 'react';
import { useEditorStore } from '@/store/editorStore';
import { createEmptyProject } from '@/lib/utils/seedProject';
import Toolbar from '@/components/editor/Toolbar';
import VideoPreview from '@/components/editor/VideoPreview';
import Timeline from '@/components/editor/Timeline';
import ScriptPanel from '@/components/editor/ScriptPanel';

export default function EditorPage({
  params,
}: {
  params: { projectId: string };
}) {
  const project = useEditorStore((s) => s.project);
  const loadProject = useEditorStore((s) => s.loadProject);

  useEffect(() => {
    // In production: fetch the persisted project (tracks, clips, assets)
    // from your API/DB by params.projectId. We seed an empty project here
    // so the editor is immediately interactive in this reference build.
    if (!project || project.id !== params.projectId) {
      loadProject(createEmptyProject(params.projectId));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.projectId]);

  if (!project) {
    return (
      <div className="h-screen flex items-center justify-center text-white/40">
        Loading project...
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-obsidian-950">
      <Toolbar />
      <div className="flex-1 grid grid-cols-[1fr_320px] gap-3 p-3 min-h-0">
        <div className="flex flex-col gap-3 min-h-0">
          <div className="flex-1 min-h-0">
            <VideoPreview />
          </div>
          <div className="h-72 shrink-0">
            <Timeline />
          </div>
        </div>
        <ScriptPanel />
      </div>
    </div>
  );
}
