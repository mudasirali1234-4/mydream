import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'CineGenius — AI Video Editing for Elite Creators',
  description:
    'Transform raw footage into cinematic, high-retention masterpieces with automated script-to-video alignment, dynamic overlays, and AI-powered editing.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-obsidian-950 text-white font-body antialiased">
        {children}
      </body>
    </html>
  );
}
