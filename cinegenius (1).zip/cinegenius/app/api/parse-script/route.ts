import { NextRequest, NextResponse } from 'next/server';
import { parseScript } from '@/lib/ai/scriptParser';
import { z } from 'zod';

const RequestSchema = z.object({
  text: z.string().min(1).max(50_000),
  style: z.enum(['documentary', 'high-retention', 'vlog', 'explainer']).optional(),
  provider: z.enum(['anthropic', 'openai', 'heuristic']).optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = RequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Invalid request body', details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const milestones = await parseScript(parsed.data);
    return NextResponse.json({ milestones });
  } catch (err) {
    console.error('[api/parse-script] failed', err);
    return NextResponse.json(
      { error: 'Script analysis failed. Please try again.' },
      { status: 500 }
    );
  }
}
