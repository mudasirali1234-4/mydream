import { NextRequest, NextResponse } from 'next/server';
import { transcribeAudio } from '@/lib/ai/transcription';
import { z } from 'zod';

const RequestSchema = z.object({
  audioUrl: z.string().url(),
  language: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = RequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Invalid request body', details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const transcript = await transcribeAudio(parsed.data);
    return NextResponse.json({ transcript });
  } catch (err) {
    console.error('[api/transcribe] failed', err);
    return NextResponse.json(
      { error: 'Transcription failed. Check your audio URL and API key.' },
      { status: 500 }
    );
  }
}
