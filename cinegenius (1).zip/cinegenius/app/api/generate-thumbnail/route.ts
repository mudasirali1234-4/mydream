import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// Note: frame extraction and canvas compositing in lib/ai/thumbnailGenerator.ts
// run in the browser (they rely on ffmpeg.wasm + HTMLCanvasElement, both
// client-only APIs). This route is the server-side counterpart for teams
// that want thumbnail generation to happen headlessly — e.g. wire it up to
// a server-side renderer (Sharp + a headless Chromium frame extractor, or
// an FFmpeg binary on a worker) and call an LLM for headline copy.

const RequestSchema = z.object({
  videoUrl: z.string().url(),
  transcriptExcerpt: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = RequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Invalid request body', details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const headline = await suggestHeadline(parsed.data.transcriptExcerpt);

  // Placeholder response — plug in your headless frame-extraction +
  // compositing worker here and return the resulting asset URL.
  return NextResponse.json({
    status: 'queued',
    message:
      'Client-side generation (lib/ai/thumbnailGenerator.ts) is the primary path. This endpoint is a stub for headless/server rendering.',
    suggestedHeadline: headline,
  });
}

async function suggestHeadline(excerpt?: string): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey || !excerpt) return 'YOU WON’T BELIEVE THIS';

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 30,
        messages: [
          {
            role: 'user',
            content: `Write a punchy, 3-5 word, high-CTR YouTube thumbnail headline (all caps, no punctuation) for a video about: "${excerpt}". Respond with only the headline text.`,
          },
        ],
      }),
    });
    const data = await res.json();
    const text = data.content?.find((c: any) => c.type === 'text')?.text;
    return text?.trim() ?? 'YOU WON’T BELIEVE THIS';
  } catch {
    return 'YOU WON’T BELIEVE THIS';
  }
}
