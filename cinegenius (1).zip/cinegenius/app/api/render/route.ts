import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import type { RenderJob } from '@/lib/types';

// ============================================================================
// Render Orchestration
// Final exports are too heavy for a serverless function's execution-time
// limits, so this route only *enqueues* the job. In production, wire the
// queue below to a durable worker:
//   - Push `job` onto a queue (SQS, Cloud Tasks, Upstash QStash, BullMQ+Redis)
//   - A worker (Fargate/Cloud Run/EC2 with FFmpeg installed, or a
//     Remotion Lambda render) pulls the project's timeline JSON, composites
//     video/audio/subtitle/3D/map layers per-frame, and encodes the output.
//   - Worker updates job status via a DB row or webhook; the client polls
//     GET /api/render/[jobId] or subscribes over a websocket/SSE channel.
// ============================================================================

const RequestSchema = z.object({
  projectId: z.string(),
  target: z.object({
    resolution: z.enum(['1080p', '4K', '9:16', '1:1']),
    format: z.enum(['mp4', 'webm', 'mov']),
    quality: z.enum(['draft', 'standard', 'high']),
  }),
});

// In-memory placeholder store. Replace with your DB/queue of choice.
const jobStore = new Map<string, RenderJob>();

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = RequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Invalid request body', details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const job: RenderJob = {
    id: `render_${nanoid(10)}`,
    projectId: parsed.data.projectId,
    status: 'queued',
    progress: 0,
    createdAt: new Date().toISOString(),
    target: parsed.data.target,
  };

  jobStore.set(job.id, job);

  // TODO: enqueue `job` to your worker/queue here.

  return NextResponse.json(job, { status: 202 });
}

export async function GET(req: NextRequest) {
  const jobId = req.nextUrl.searchParams.get('jobId');
  if (!jobId) {
    return NextResponse.json({ error: 'jobId query param required' }, { status: 400 });
  }
  const job = jobStore.get(jobId);
  if (!job) {
    return NextResponse.json({ error: 'Job not found' }, { status: 404 });
  }
  return NextResponse.json(job);
}
