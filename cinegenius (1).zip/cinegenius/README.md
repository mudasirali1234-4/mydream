# CineGenius

AI-powered video editing and automation platform for elite content creators.
Turns raw footage + a script/document into a cinematically edited, high-retention
cut — automated smart cuts, slow-motion beats, subtitle highlighting, 3D overlays,
and animated map graphics, all driven by a multitrack timeline.

## Stack

| Layer | Choice | Why |
|---|---|---|
| Framework | Next.js 14 (App Router) | Server routes for AI/render orchestration + client editor in one repo |
| UI | React 18, Tailwind CSS | Fast iteration, dark studio theme in `tailwind.config.ts` |
| State | Zustand | Lightweight, no boilerplate, works well with a large mutable timeline graph |
| AI — script analysis | Claude (Anthropic Messages API) | Narrative milestone extraction, `lib/ai/scriptParser.ts` |
| AI — transcription | Whisper (OpenAI Audio API) | Word-level timings, `lib/ai/transcription.ts` |
| Video processing | ffmpeg.wasm | In-browser frame extraction, scene detection, proxies — `lib/video/ffmpeg.ts` |
| 3D | three.js + @react-three/fiber | Overlay rendering, `components/editor/Overlay3DRenderer.tsx` |
| Maps | Mapbox GL + react-map-gl | Animated route reveals, `components/editor/MapOverlayRenderer.tsx` |

## Project structure

```
app/
  page.tsx                     Landing page
  dashboard/page.tsx           Project list + upload
  editor/[projectId]/page.tsx  Main editor (preview + timeline + AI panel)
  api/
    parse-script/route.ts      POST -> ScriptMilestone[]
    transcribe/route.ts        POST -> TranscriptResult (Whisper)
    generate-thumbnail/route.ts  Server-side thumbnail stub + AI headline copy
    render/route.ts            Enqueues a server-side export job

components/
  dashboard/  UploadZone, ProjectCard
  editor/     Toolbar, VideoPreview, Timeline, TimelineTrack, TimelineClip,
              ScriptPanel, Overlay3DRenderer, MapOverlayRenderer

lib/
  types.ts               Domain model: Project, Track, Clip variants, AI types
  ai/
    scriptParser.ts       Document -> narrative milestones (LLM + heuristic fallback)
    alignment.ts          Milestones -> real timestamps via transcript fuzzy match
    transcription.ts      Whisper wrapper
    thumbnailGenerator.ts Frame scoring + canvas compositing
  video/ffmpeg.ts          ffmpeg.wasm wrapper: frames, scene detection, proxies
  utils/seedProject.ts      Empty-project scaffold for new editor sessions

store/editorStore.ts        Zustand store: tracks, clips, playhead, undo/redo
```

## How the AI pipeline fits together

1. **Upload** — creator drops raw footage + a script/doc in the dashboard.
2. **Transcribe** — `POST /api/transcribe` runs Whisper on the extracted audio
   track, returning word-level timings (`TranscriptResult`).
3. **Parse** — `POST /api/parse-script` sends the document text to Claude,
   which segments it into `ScriptMilestone[]` (hook, evidence, emotional
   peak, CTA, punchline, etc.), each with a suggested `EditingAction`.
4. **Align** — `lib/ai/alignment.ts` fuzzy-matches each milestone's excerpt
   against the transcript's word stream to resolve a concrete video
   timestamp (`milestone.mappedTimestamp`).
5. **Apply** — the editor UI (`ScriptPanel.tsx`) lets the creator jump the
   playhead to any milestone and one-click apply its suggested action
   (smart cut, slow-mo ramp, text highlight, etc.) directly onto the
   timeline via the Zustand store.

Every AI call degrades gracefully: if `ANTHROPIC_API_KEY`/`OPENAI_API_KEY`
aren't set, `scriptParser.ts` falls back to a deterministic sentence-level
heuristic so the editor stays usable in local dev without keys.

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in your API keys
npm run dev
```

Open `http://localhost:3000`.

### Required environment variables

See `.env.example`. At minimum for local dev:
- `ANTHROPIC_API_KEY` — script milestone extraction
- `OPENAI_API_KEY` — Whisper transcription
- `NEXT_PUBLIC_MAPBOX_TOKEN` — map overlay track

## What's production-scaffolded vs. what you still need to wire up

This repo is a complete, working architecture and reference implementation.
Two pieces are intentionally left as integration points rather than baked-in
choices, since they're deployment-specific:

- **Persistence** — `dashboard/page.tsx` uses an in-memory mock project list
  and `api/render/route.ts` uses an in-memory job map. Swap in your DB
  (Postgres/Prisma, Supabase, PlanetScale) — the `Project`/`RenderJob` types
  in `lib/types.ts` are your schema starting point.
- **Final render worker** — `ffmpeg.wasm` handles fast, in-browser previews
  (frame extraction, scene detection, proxies) but full-quality final export
  of a multi-layer timeline (video + audio ducking + subtitles + 3D +
  maps) belongs on a server worker with native FFmpeg or a frame-server
  renderer (e.g. Remotion). `api/render/route.ts` documents the queue/worker
  contract to plug into.

## Deployment

Both `vercel.json` and `netlify.toml` are included and set the
`Cross-Origin-Opener-Policy` / `Cross-Origin-Embedder-Policy` headers that
`ffmpeg.wasm` requires for `SharedArrayBuffer`. Deploy with:

```bash
# Vercel
vercel deploy

# Netlify
netlify deploy
```
