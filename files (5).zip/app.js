/* =========================================================================
   DimensionCalc — Application logic
   Sections: State, Mode switching, Standard/Scientific calculator engine,
   Unit converter, Tiny math-expression parser, Custom 3D surface renderer,
   Premium modal, Offline / PWA bootstrap.
   ========================================================================= */

(() => {
  "use strict";

  /* ---------------------------------------------------------------------
     0. Persistent state
     --------------------------------------------------------------------- */
  const state = {
    premium: localStorage.getItem("dc_premium") === "1",
    mode: "standard",
    graphTheme: "cyan",
  };

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  /* ---------------------------------------------------------------------
     1. Mode / tab switching
     --------------------------------------------------------------------- */
  const tabs = $$(".tab");
  const panels = {
    standard: $("#panel-standard"),
    scientific: $("#panel-standard"), // scientific reuses the calc panel
    convert: $("#panel-convert"),
    graph: $("#panel-graph"),
  };
  const sciKeys = $("#keysScientific");

  function setMode(mode) {
    if (mode === "scientific" && !state.premium) {
      openPremium();
      return;
    }
    state.mode = mode;

    tabs.forEach((t) => {
      const active = t.dataset.mode === mode;
      t.classList.toggle("active", active);
      t.setAttribute("aria-selected", String(active));
    });

    // Show/hide top-level panels
    $("#panel-standard").hidden = !(mode === "standard" || mode === "scientific");
    $("#panel-convert").hidden = mode !== "convert";
    $("#panel-graph").hidden = mode !== "graph";

    // Toggle scientific key row
    sciKeys.classList.toggle("visible", mode === "scientific");

    if (mode === "graph") requestAnimationFrame(() => graph.resize());
  }

  tabs.forEach((t) => t.addEventListener("click", () => setMode(t.dataset.mode)));

  /* ---------------------------------------------------------------------
     2. Standard + Scientific calculator engine
     --------------------------------------------------------------------- */
  const mainDisplay = $("#mainDisplay");
  const historyLine = $("#historyLine");

  const calc = {
    current: "0",
    previous: null,
    operator: null,
    justEvaluated: false,
  };

  function formatNumber(numStr) {
    if (numStr === "Error") return numStr;
    const num = Number(numStr);
    if (!isFinite(num)) return "Error";
    // Trim floating point noise, keep up to 10 significant digits
    let out = parseFloat(num.toPrecision(10)).toString();
    if (out.length > 14) out = num.toExponential(6);
    return out;
  }

  function renderCalc() {
    mainDisplay.textContent = calc.current;
    historyLine.textContent = calc.previous !== null
      ? `${formatNumber(calc.previous)} ${calc.operator ?? ""}`
      : "\u00A0";
  }

  function inputDigit(d) {
    if (calc.justEvaluated) {
      calc.current = "0";
      calc.justEvaluated = false;
    }
    if (d === "." ) {
      if (calc.current.includes(".")) return;
      calc.current = calc.current === "0" ? "0." : calc.current + ".";
      return;
    }
    calc.current = calc.current === "0" ? d : calc.current + d;
    if (calc.current.replace(/[-.]/g, "").length > 14) calc.current = calc.current.slice(0, -1);
  }

  function chooseOperator(op) {
    if (calc.operator && !calc.justEvaluated) {
      evaluate();
    }
    calc.previous = calc.current;
    calc.operator = op;
    calc.current = "0";
    calc.justEvaluated = false;
  }

  function evaluate() {
    if (calc.operator === null || calc.previous === null) return;
    const a = parseFloat(calc.previous);
    const b = parseFloat(calc.current);
    let result;
    switch (calc.operator) {
      case "+": result = a + b; break;
      case "−": result = a - b; break;
      case "×": result = a * b; break;
      case "÷": result = b === 0 ? NaN : a / b; break;
      default: return;
    }
    calc.current = formatNumber(String(result));
    calc.previous = null;
    calc.operator = null;
    calc.justEvaluated = true;
  }

  function clearAll() {
    calc.current = "0";
    calc.previous = null;
    calc.operator = null;
    calc.justEvaluated = false;
  }

  function backspace() {
    if (calc.justEvaluated) { clearAll(); return; }
    calc.current = calc.current.length > 1 ? calc.current.slice(0, -1) : "0";
  }

  function percent() {
    calc.current = formatNumber(String(parseFloat(calc.current) / 100));
  }

  function applyScientific(fn) {
    const x = parseFloat(calc.current);
    let result;
    switch (fn) {
      case "sin": result = Math.sin(x * Math.PI / 180); break;
      case "cos": result = Math.cos(x * Math.PI / 180); break;
      case "tan": result = Math.tan(x * Math.PI / 180); break;
      case "sqrt": result = Math.sqrt(x); break;
      case "pow2": result = x * x; break;
      case "log": result = Math.log10(x); break;
      case "ln": result = Math.log(x); break;
      case "pi": result = Math.PI; break;
      case "inv": result = 1 / x; break;
      case "fact": {
        if (x < 0 || !Number.isInteger(x) || x > 170) { result = NaN; break; }
        let f = 1; for (let i = 2; i <= x; i++) f *= i;
        result = f;
        break;
      }
      default: return;
    }
    calc.current = formatNumber(String(result));
    calc.justEvaluated = true;
  }

  $("#keysStandard").addEventListener("click", (e) => {
    const btn = e.target.closest(".key");
    if (!btn) return;
    if (btn.dataset.num !== undefined) inputDigit(btn.dataset.num);
    else if (btn.dataset.op !== undefined) chooseOperator(btn.dataset.op);
    else if (btn.dataset.action === "equals") evaluate();
    else if (btn.dataset.action === "clear") clearAll();
    else if (btn.dataset.action === "backspace") backspace();
    else if (btn.dataset.action === "percent") percent();
    renderCalc();
  });

  sciKeys.addEventListener("click", (e) => {
    const btn = e.target.closest(".key-sci");
    if (!btn) return;
    applyScientific(btn.dataset.sci);
    renderCalc();
  });

  // Basic keyboard support
  window.addEventListener("keydown", (e) => {
    if (state.mode !== "standard" && state.mode !== "scientific") return;
    if (/^[0-9]$/.test(e.key)) inputDigit(e.key);
    else if (e.key === ".") inputDigit(".");
    else if (e.key === "+") chooseOperator("+");
    else if (e.key === "-") chooseOperator("−");
    else if (e.key === "*") chooseOperator("×");
    else if (e.key === "/") { e.preventDefault(); chooseOperator("÷"); }
    else if (e.key === "Enter" || e.key === "=") evaluate();
    else if (e.key === "Backspace") backspace();
    else if (e.key === "Escape") clearAll();
    else return;
    renderCalc();
  });

  renderCalc();

  /* ---------------------------------------------------------------------
     3. Unit converter
     --------------------------------------------------------------------- */
  const UNITS = {
    length: {
      base: "m",
      units: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254, nmi: 1852 },
    },
    weight: {
      base: "kg",
      units: { kg: 1, g: 0.001, mg: 0.000001, lb: 0.45359237, oz: 0.028349523, ton: 1000, stone: 6.35029 },
    },
    area: {
      base: "m2",
      units: { m2: 1, km2: 1e6, cm2: 0.0001, ha: 10000, acre: 4046.8564224, ft2: 0.09290304, yd2: 0.83612736, mi2: 2589988.110336 },
    },
    speed: {
      base: "mps",
      units: { mps: 1, kmh: 0.277777778, mph: 0.44704, knot: 0.514444444, fts: 0.3048 },
    },
    data: {
      base: "byte",
      units: { byte: 1, KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3, TB: 1024 ** 4, bit: 0.125 },
    },
    temperature: { base: "C", units: { C: "C", F: "F", K: "K" } }, // handled specially
  };

  let currentCategory = "length";
  const catRow = $("#convertCategoryRow");
  const fromVal = $("#convertFromValue");
  const toVal = $("#convertToValue");
  const fromUnit = $("#convertFromUnit");
  const toUnit = $("#convertToUnit");

  function populateUnitSelects(category) {
    const list = Object.keys(UNITS[category].units);
    [fromUnit, toUnit].forEach((sel, i) => {
      sel.innerHTML = list.map((u) => `<option value="${u}">${u}</option>`).join("");
      sel.selectedIndex = i === 0 ? 0 : Math.min(1, list.length - 1);
    });
  }

  function tempConvert(value, from, to) {
    let celsius;
    if (from === "C") celsius = value;
    else if (from === "F") celsius = (value - 32) * 5 / 9;
    else celsius = value - 273.15; // K
    if (to === "C") return celsius;
    if (to === "F") return celsius * 9 / 5 + 32;
    return celsius + 273.15; // K
  }

  function runConversion() {
    const val = parseFloat(fromVal.value);
    if (isNaN(val)) { toVal.value = ""; return; }
    const cat = UNITS[currentCategory];
    let result;
    if (currentCategory === "temperature") {
      result = tempConvert(val, fromUnit.value, toUnit.value);
    } else {
      const baseVal = val * cat.units[fromUnit.value];
      result = baseVal / cat.units[toUnit.value];
    }
    toVal.value = parseFloat(result.toPrecision(10)).toString();
  }

  catRow.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $$(".chip", catRow).forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    currentCategory = chip.dataset.cat;
    populateUnitSelects(currentCategory);
    runConversion();
  });

  [fromVal, fromUnit, toUnit].forEach((el) => el.addEventListener("input", runConversion));
  $("#swapUnits").addEventListener("click", () => {
    const tmp = fromUnit.value;
    fromUnit.value = toUnit.value;
    toUnit.value = tmp;
    fromVal.value = toVal.value || fromVal.value;
    runConversion();
  });

  populateUnitSelects(currentCategory);
  runConversion();

  /* ---------------------------------------------------------------------
     4. Tiny safe math-expression parser (supports x, y, + - * / ^ () and
        common functions) — no eval(), fully offline-safe.
     --------------------------------------------------------------------- */
  function evalFormula(expr, x, y) {
    let pos = 0;
    const s = expr.replace(/\s+/g, "");

    function peek() { return s[pos]; }
    function consume(ch) { if (s[pos] === ch) { pos++; return true; } return false; }

    function parseExpr() {
      let v = parseTerm();
      while (peek() === "+" || peek() === "-") {
        const op = s[pos++];
        const rhs = parseTerm();
        v = op === "+" ? v + rhs : v - rhs;
      }
      return v;
    }
    function parseTerm() {
      let v = parseFactor();
      while (peek() === "*" || peek() === "/") {
        const op = s[pos++];
        const rhs = parseFactor();
        v = op === "*" ? v * rhs : v / rhs;
      }
      return v;
    }
    function parseFactor() {
      let v = parseUnary();
      while (peek() === "^") {
        pos++;
        const rhs = parseUnary();
        v = Math.pow(v, rhs);
      }
      return v;
    }
    function parseUnary() {
      if (consume("-")) return -parseUnary();
      if (consume("+")) return parseUnary();
      return parseAtom();
    }
    function parseAtom() {
      if (consume("(")) {
        const v = parseExpr();
        consume(")");
        return v;
      }
      const numMatch = /^[0-9]*\.?[0-9]+/.exec(s.slice(pos));
      if (numMatch) { pos += numMatch[0].length; return parseFloat(numMatch[0]); }

      const idMatch = /^[a-zA-Z]+/.exec(s.slice(pos));
      if (idMatch) {
        const id = idMatch[0];
        pos += id.length;
        if (id === "x") return x;
        if (id === "y") return y;
        if (id === "pi") return Math.PI;
        if (id === "e") return Math.E;
        // function call
        if (consume("(")) {
          const arg = parseExpr();
          // allow two-arg functions like pow(x,y) or atan2
          let arg2 = null;
          if (consume(",")) arg2 = parseExpr();
          consume(")");
          switch (id) {
            case "sin": return Math.sin(arg);
            case "cos": return Math.cos(arg);
            case "tan": return Math.tan(arg);
            case "sqrt": return Math.sqrt(arg);
            case "abs": return Math.abs(arg);
            case "log": return Math.log10(arg);
            case "ln": return Math.log(arg);
            case "exp": return Math.exp(arg);
            case "pow": return Math.pow(arg, arg2 ?? 2);
            case "atan2": return Math.atan2(arg, arg2 ?? 0);
            case "max": return Math.max(arg, arg2 ?? arg);
            case "min": return Math.min(arg, arg2 ?? arg);
            default: return NaN;
          }
        }
        return NaN;
      }
      return NaN;
    }

    try {
      const v = parseExpr();
      return isFinite(v) ? v : 0;
    } catch (err) {
      return 0;
    }
  }

  /* ---------------------------------------------------------------------
     5. Custom 3D surface renderer (no external libraries, offline-safe)
     --------------------------------------------------------------------- */
  const graph = (() => {
    const canvas = $("#graphCanvas");
    const ctx = canvas.getContext("2d");
    let rotX = -0.6, rotY = 0.5, zoom = 1;
    let dragging = false, lastX = 0, lastY = 0;
    let formula = "sin(sqrt(x*x+y*y))";
    const RANGE = 4, STEPS = 28;
    let animFrame = null;

    const THEMES = {
      cyan:   { lo: [8, 20, 45],   hi: [34, 211, 238] },
      magma:  { lo: [40, 8, 8],    hi: [255, 107, 107] },
      aurora: { lo: [10, 30, 60],  hi: [139, 92, 246] },
      gold:   { lo: [40, 28, 6],   hi: [245, 185, 66] },
    };

    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      draw();
    }

    function project(x, y, z, w, h) {
      // Rotate around X then Y
      let cosX = Math.cos(rotX), sinX = Math.sin(rotX);
      let y1 = y * cosX - z * sinX;
      let z1 = y * sinX + z * cosX;
      let cosY = Math.cos(rotY), sinY = Math.sin(rotY);
      let x2 = x * cosY + z1 * sinY;
      let z2 = -x * sinY + z1 * cosY;

      const scale = Math.min(w, h) * 0.11 * zoom;
      const perspective = 1 / (1 + z2 * 0.04);
      return {
        sx: w / 2 + x2 * scale * perspective,
        sy: h / 2 + y1 * scale * perspective * -1 + h * 0.06,
        depth: z2,
      };
    }

    function lerpColor(t, theme) {
      const { lo, hi } = THEMES[theme];
      const c = lo.map((v, i) => Math.round(v + (hi[i] - v) * t));
      return `rgb(${c[0]},${c[1]},${c[2]})`;
    }

    function computeGrid() {
      const pts = [];
      let zMin = Infinity, zMax = -Infinity;
      for (let i = 0; i <= STEPS; i++) {
        const row = [];
        const x = -RANGE + (2 * RANGE * i) / STEPS;
        for (let j = 0; j <= STEPS; j++) {
          const y = -RANGE + (2 * RANGE * j) / STEPS;
          let z = evalFormula(formula, x, y);
          if (!isFinite(z)) z = 0;
          z = Math.max(-6, Math.min(6, z));
          zMin = Math.min(zMin, z);
          zMax = Math.max(zMax, z);
          row.push({ x, y, z });
        }
        pts.push(row);
      }
      return { pts, zMin, zMax };
    }

    let cached = computeGrid();

    function draw() {
      const w = canvas.clientWidth, h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);
      const { pts, zMin, zMax } = cached;
      const range = zMax - zMin || 1;

      // Build quads with average depth for painter's algorithm
      const quads = [];
      for (let i = 0; i < pts.length - 1; i++) {
        for (let j = 0; j < pts[i].length - 1; j++) {
          const p00 = pts[i][j], p10 = pts[i + 1][j], p11 = pts[i + 1][j + 1], p01 = pts[i][j + 1];
          const c00 = project(p00.x, p00.y, p00.z, w, h);
          const c10 = project(p10.x, p10.y, p10.z, w, h);
          const c11 = project(p11.x, p11.y, p11.z, w, h);
          const c01 = project(p01.x, p01.y, p01.z, w, h);
          const avgDepth = (c00.depth + c10.depth + c11.depth + c01.depth) / 4;
          const avgZ = (p00.z + p10.z + p11.z + p01.z) / 4;
          quads.push({ c00, c10, c11, c01, depth: avgDepth, t: (avgZ - zMin) / range });
        }
      }
      quads.sort((a, b) => b.depth - a.depth);

      for (const q of quads) {
        ctx.beginPath();
        ctx.moveTo(q.c00.sx, q.c00.sy);
        ctx.lineTo(q.c10.sx, q.c10.sy);
        ctx.lineTo(q.c11.sx, q.c11.sy);
        ctx.lineTo(q.c01.sx, q.c01.sy);
        ctx.closePath();
        ctx.fillStyle = lerpColor(q.t, state.graphTheme);
        ctx.fill();
        ctx.strokeStyle = "rgba(0,0,0,0.25)";
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }

    function replot(newFormula) {
      formula = newFormula ?? formula;
      cached = computeGrid();
      draw();
    }

    // Drag-to-rotate (mouse + touch)
    function pointerDown(x, y) { dragging = true; lastX = x; lastY = y; }
    function pointerMove(x, y) {
      if (!dragging) return;
      rotY += (x - lastX) * 0.008;
      rotX += (y - lastY) * 0.008;
      rotX = Math.max(-1.4, Math.min(1.4, rotX));
      lastX = x; lastY = y;
      draw();
    }
    function pointerUp() { dragging = false; }

    canvas.addEventListener("mousedown", (e) => pointerDown(e.clientX, e.clientY));
    window.addEventListener("mousemove", (e) => pointerMove(e.clientX, e.clientY));
    window.addEventListener("mouseup", pointerUp);

    canvas.addEventListener("touchstart", (e) => {
      const t = e.touches[0]; pointerDown(t.clientX, t.clientY);
    }, { passive: true });
    canvas.addEventListener("touchmove", (e) => {
      const t = e.touches[0]; pointerMove(t.clientX, t.clientY); e.preventDefault();
    }, { passive: false });
    canvas.addEventListener("touchend", pointerUp);

    canvas.addEventListener("wheel", (e) => {
      e.preventDefault();
      zoom = Math.max(0.4, Math.min(2.5, zoom - e.deltaY * 0.001));
      draw();
    }, { passive: false });

    // Gentle idle auto-rotate for visual appeal until user interacts
    let userInteracted = false;
    ["mousedown", "touchstart", "wheel"].forEach((ev) =>
      canvas.addEventListener(ev, () => (userInteracted = true), { once: true })
    );
    function idleSpin() {
      if (!userInteracted && !dragging) { rotY += 0.0025; draw(); }
      animFrame = requestAnimationFrame(idleSpin);
    }
    idleSpin();

    window.addEventListener("resize", resize);

    return { resize, replot, draw };
  })();

  $("#plotBtn").addEventListener("click", () => {
    const val = $("#graphFormula").value.trim() || "0";
    graph.replot(val);
  });
  $("#graphFormula").addEventListener("keydown", (e) => {
    if (e.key === "Enter") $("#plotBtn").click();
  });

  $$(".theme-dot").forEach((dot) => {
    dot.addEventListener("click", () => {
      const theme = dot.dataset.theme;
      if (dot.classList.contains("locked") && !state.premium) { openPremium(); return; }
      state.graphTheme = theme;
      $$(".theme-dot").forEach((d) => d.classList.remove("active"));
      dot.classList.add("active");
      graph.draw();
    });
  });

  /* ---------------------------------------------------------------------
     6. Premium modal
     --------------------------------------------------------------------- */
  const overlay = $("#premiumOverlay");
  function openPremium() { overlay.hidden = false; }
  function closePremium() { overlay.hidden = true; }

  $("#openPremium").addEventListener("click", openPremium);
  $("#closePremium").addEventListener("click", closePremium);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closePremium(); });

  function showToast(msg) {
    let toast = $(".toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast";
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    requestAnimationFrame(() => toast.classList.add("show"));
    setTimeout(() => toast.classList.remove("show"), 2400);
  }

  function applyPremiumUI() {
    $$(".tab .lock").forEach((l) => (l.style.display = state.premium ? "none" : ""));
    $$(".theme-dot.locked").forEach((d) => {
      if (state.premium) d.classList.remove("locked");
    });
  }

  $("#unlockPremium").addEventListener("click", () => {
    state.premium = true;
    localStorage.setItem("dc_premium", "1");
    applyPremiumUI();
    closePremium();
    showToast("✨ Premium unlocked — enjoy DimensionCalc in full!");
  });

  applyPremiumUI();

  /* ---------------------------------------------------------------------
     7. Offline / PWA bootstrap
     --------------------------------------------------------------------- */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => {
        /* offline registration failure is non-fatal */
      });
    });
  }

  const offlineBadge = $("#offlineBadge");
  function updateOnlineStatus() { offlineBadge.hidden = navigator.onLine; }
  window.addEventListener("online", updateOnlineStatus);
  window.addEventListener("offline", updateOnlineStatus);
  updateOnlineStatus();

  // Initial layout pass once fonts/layout settle
  window.addEventListener("load", () => graph.resize());
})();
